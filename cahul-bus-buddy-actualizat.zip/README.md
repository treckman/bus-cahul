# CahulGo Transit

Creează aplicația CahulRutier pentru transportul public din orașul Cahul (în loc de CahulRoute):

1. Mod Călător:
- Hartă interactivă centrată pe Cahul cu traseele rutierelor (ex. Liniile 1, 2, 3) și stațiile principale.
- Vizualizarea rutierelor active pe traseu în timp real cu indicarea numărului liniei.
- La selectarea unei stații, afișează estimarea timpului de sosire (ETA) pentru rutierele care se apropie.
- Tab „Linii și orare” cu lista completă a stațiilor și orarele de plecare de la capete.

2. Mod Șofer:
- Selectare nume și alegere linie.
- Buton mare „Pornește Cursa” (verde) / „Oprește Cursa” (roșu) pentru pornirea/oprirea transmiterii locației.
- Transmitere poziție GPS în timp real.
- Mod Simulare: opțiune de a rula o cursă simulată pe traseu pentru a testa vizualizarea pe hartă fără GPS real.

3. Interfață și design:
- Numele aplicației: CahulRutier.
- Interfață optimizată pentru mobil, fonturi mari, butoane mari ușor de apăsat, culori contrastante (galben transport, albastru, verde, roșu).
- Comutator temă deschisă / întunecată.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://cahul-bus-buddy.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/2ed0f140-6b53-4602-96fe-9e775a8c0c32).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
