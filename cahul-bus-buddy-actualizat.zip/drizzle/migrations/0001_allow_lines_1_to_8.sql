DROP POLICY "insert vehicles" ON public.vehicles;
DROP POLICY "update vehicles" ON public.vehicles;
CREATE POLICY "insert vehicles" ON public.vehicles FOR INSERT TO anon, authenticated WITH CHECK (line IN ('1','2','3','4','5','6','7','8') AND length(driver_name) BETWEEN 1 AND 60);
CREATE POLICY "update vehicles" ON public.vehicles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (line IN ('1','2','3','4','5','6','7','8') AND length(driver_name) BETWEEN 1 AND 60);