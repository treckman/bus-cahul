CREATE TABLE public.vehicles (
  id uuid PRIMARY KEY,
  driver_name text NOT NULL,
  line text NOT NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  simulated boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO anon, authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read vehicles" ON public.vehicles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert vehicles" ON public.vehicles FOR INSERT TO anon, authenticated WITH CHECK (line IN ('1','2','3') AND length(driver_name) BETWEEN 1 AND 60);
CREATE POLICY "update vehicles" ON public.vehicles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (line IN ('1','2','3') AND length(driver_name) BETWEEN 1 AND 60);
CREATE POLICY "delete vehicles" ON public.vehicles FOR DELETE TO anon, authenticated USING (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.vehicles;