-- One active vehicle per authenticated account. Deploy together with the app.
-- Old anonymous vehicle IDs become read-only and age out of the map after 2 min.
begin;
alter table public.vehicles enable row level security;
do $$
declare policy_row record;
begin
  for policy_row in select policyname from pg_policies where schemaname = 'public' and tablename = 'vehicles'
  loop
    execute format('drop policy %I on public.vehicles', policy_row.policyname);
  end loop;
end $$;
create policy "Vehicles visible to passengers" on public.vehicles
for select to anon, authenticated using (true);
create policy "Account inserts its own vehicle" on public.vehicles
for insert to authenticated with check (id::text = (select auth.uid())::text);
create policy "Account updates its own vehicle" on public.vehicles
for update to authenticated using (id::text = (select auth.uid())::text)
with check (id::text = (select auth.uid())::text);
create policy "Account deletes its own vehicle" on public.vehicles
for delete to authenticated using (id::text = (select auth.uid())::text);
commit;
