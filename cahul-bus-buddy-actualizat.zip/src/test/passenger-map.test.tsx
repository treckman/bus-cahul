import { QueryClient } from "@tanstack/react-query";
import { createMemoryHistory, createRouter, RouterProvider } from "@tanstack/react-router";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import type { ComponentType, ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { PLACES } from "@/lib/places";
import { routeTree } from "@/routeTree.gen";

// The production shell renders a complete HTML document. A component test
// mounts into a div, so use a fragment shell to avoid React document hoisting.
const testRootOptions = routeTree.options as typeof routeTree.options & {
  shellComponent?: ComponentType<{ children: ReactNode }>;
};
testRootOptions.shellComponent = ({ children }) => <>{children}</>;

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: () => ({ select: () => Promise.resolve({ data: [] }) }),
    channel: () => {
      const channel = { on: () => channel, subscribe: () => channel };
      return channel;
    },
    removeChannel: vi.fn(),
    auth: {
      getSession: () => Promise.resolve({ data: { session: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: vi.fn() } } }),
    },
  },
}));

vi.mock("@/components/MapView", () => ({
  MapView: ({ filter, selectedPlace }: { filter: string; selectedPlace: string | null }) => (
    <>
      <div data-testid="map-route">{filter}</div>
      <div data-testid="map-place">{selectedPlace}</div>
    </>
  ),
}));
beforeEach(() => {
  localStorage.clear();
  localStorage.setItem("cr-layout", "desktop");
});
function renderAt(path: string) {
  const queryClient = new QueryClient();
  const router = createRouter({
    routeTree,
    context: { queryClient },
    history: createMemoryHistory({ initialEntries: [path] }),
  });
  return render(<RouterProvider router={router} />);
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

describe("Passenger map", () => {
  it("offers device layouts and keeps the public contact links below the app", async () => {
    renderAt("/");
    fireEvent.click(await screen.findByRole("button", { name: "Alege telefon sau calculator" }));
    expect(await screen.findByRole("dialog")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Mobil", exact: true }));
    expect(localStorage.getItem("cr-layout")).toBe("mobile");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: /alexbuac_803/ })).toHaveAttribute(
      "href",
      "https://www.instagram.com/alexbuac_803/",
    );
    expect(screen.getByRole("link", { name: /373 788/ })).toHaveAttribute(
      "href",
      "tel:+37378804063",
    );
    for (const handle of ["treck.man", "eugen00p", "dcappro"]) {
      expect(screen.getByRole("link", { name: `Instagram @${handle}` })).toHaveAttribute(
        "href",
        `https://www.instagram.com/${handle}/`,
      );
    }
    for (const number of ["+37378085420", "+37367618046", "+37367781429"]) {
      expect(document.querySelector(`a[href="tel:${number}"]`)).toBeInTheDocument();
    }
  });
  it("keeps the selected route on the map after closing details and changes stop order for return", async () => {
    renderAt("/");
    fireEvent.click(await screen.findByRole("button", { name: "1" }));
    expect(
      screen.queryByRole("button", { name: "Închide detaliile rutei" }),
    ).not.toBeInTheDocument();
    expect(screen.queryByText(/Orarul din documentul Primăriei/)).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Arată opririle rutei" }));
    await screen.findByRole("button", { name: "1. str. Dunării 2" });
    fireEvent.click(screen.getByRole("button", { name: "← Retur" }));
    expect(screen.getByRole("button", { name: "1. str. Strada Veche 147" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Închide detaliile rutei" }));
    expect(
      screen.queryByRole("button", { name: "Închide detaliile rutei" }),
    ).not.toBeInTheDocument();
    expect(screen.getByTestId("map-route")).toHaveTextContent("1");
    expect(screen.getByRole("button", { name: "1" })).toHaveAttribute("aria-pressed", "true");
  });
  it("saves favorites on the device without asking the passenger to sign in", async () => {
    renderAt("/");
    fireEvent.click(await screen.findByRole("button", { name: "2" }));
    fireEvent.click(await screen.findByRole("button", { name: "Adaugă ruta la favorite" }));
    expect(JSON.parse(localStorage.getItem("cr-favorites")!)).toEqual(["2"]);
    expect(screen.getByRole("button", { name: "★ Ruta 2" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Cont" })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Șofer" }));
    expect(await screen.findByRole("heading", { name: "Conectare șofer" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Google|Gmail/ })).not.toBeInTheDocument();
  });
  it("finds a named local place and centers the map there without selecting a bus stop", async () => {
    const place = PLACES.find((p) => p.name === "Euro Garage service")!;
    renderAt("/");
    fireEvent.change(await screen.findByLabelText("Caută o stație sau un loc"), {
      target: { value: "Euro Garage" },
    });
    fireEvent.click(await screen.findByRole("button", { name: /Euro Garage service/ }));
    expect(screen.getByTestId("map-place")).toHaveTextContent(place.id);
    expect(screen.getByLabelText("Caută o stație sau un loc")).toHaveValue("");
    expect(
      screen.queryByRole("button", { name: "Închide detaliile rutei" }),
    ).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "8" }));
    await waitFor(() => expect(screen.getByTestId("map-place")).toBeEmptyDOMElement());
  });
});
