import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { Account } from "@/components/Account";

const auth = vi.hoisted(() => ({
  signInWithOtp: vi.fn(),
  verifyOtp: vi.fn(),
  signInWithOAuth: vi.fn(),
  signOut: vi.fn(),
}));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { auth } }));
beforeEach(() => {
  vi.resetAllMocks();
});
afterEach(cleanup);

describe("Driver email authentication", () => {
  it("verifies the code against the email that received it and allows retry after an invalid code", async () => {
    auth.signInWithOtp.mockResolvedValue({ error: null });
    auth.verifyOtp.mockResolvedValue({ error: new Error("Invalid OTP") });
    render(<Account user={null} loading={false} error="" />);
    fireEvent.change(screen.getByLabelText("Adresa de email"), {
      target: { value: "Ion@gmail.com" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Trimite codul" }));
    await screen.findByLabelText("Codul din email");
    expect(auth.signInWithOtp).toHaveBeenCalledWith({
      email: "ion@gmail.com",
      options: { emailRedirectTo: window.location.origin + "/" },
    });
    expect(screen.getByLabelText("Adresa de email")).toBeDisabled();
    fireEvent.change(screen.getByLabelText("Codul din email"), { target: { value: "123456" } });
    fireEvent.click(screen.getByRole("button", { name: "Conectează-te" }));
    await waitFor(() =>
      expect(auth.verifyOtp).toHaveBeenCalledWith({
        email: "ion@gmail.com",
        token: "123456",
        type: "email",
      }),
    );
    await screen.findByText("Codul nu este valid sau a expirat. Solicită un cod nou.");
    expect(screen.getByRole("button", { name: "Conectează-te" })).toBeEnabled();
    expect(screen.getByRole("button", { name: /Retrimite în/ })).toBeDisabled();
  });
  it("offers email access for drivers without Google login", () => {
    render(<Account user={null} loading={false} error="" />);
    expect(screen.queryByRole("button", { name: /Google|Gmail/ })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Trimite codul" })).toBeEnabled();
  });
});
