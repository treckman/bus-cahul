import { describe, expect, it } from "vitest";
import { scheduledDepartures, servicesForLine } from "@/lib/schedule";
import {
  LINES,
  loopPath,
  pointAt,
  routePath,
  routeStops,
  stopById,
  haversine,
  etaMinutes,
} from "@/lib/transit";
import corrections from "@/lib/route-corrections.json";

type P = [number, number];
const line = (id: string) => LINES.find((l) => l.id === id)!;
const near = (path: P[], p: P) => Math.min(...path.map((v) => haversine(v, p)));

describe("Municipal timetable", () => {
  it("preserves route 6 endpoint times, including return-only rows", () => {
    const first = servicesForLine("6").find((s) => s.code === "6/6")!.trips[0]!;
    expect(first.outboundDeparture).toBeNull();
    expect(first.inboundDeparture).toBe("07:44");
    expect(scheduledDepartures("6", "outbound", "6/1").slice(0, 2)).toEqual(["07:24", "08:10"]);
    expect(scheduledDepartures("6", "inbound", "6/6")).toContain("07:44");
  });
});

describe("Corrected routes", () => {
  it("keeps route 1 on the main street and sends route 5 to Lapaevca", () => {
    expect(line("1").stops.at(-1)).toBe("veche147");
    expect(line("5").stops[0]).toBe("viilor");
    expect(line("5").stops.at(-1)).toBe("mv51");
    expect(line("5").stops.slice(-3)).toEqual(["garaauto", "mv27", "mv51"]);
    expect(line("5").stops).not.toContain("veche147");
    for (const id of ["1", "5"]) {
      expect(line(id).unlocatedStops).toContain("pat8");
      for (const direction of ["outbound", "inbound"] as const) {
        const path = routePath(line(id), direction);
        for (const p of corrections["1"].streetCorridor as P[]) {
          if (p[0] <= stopById("scm122").lat) expect(near(path, p)).toBeLessThan(45);
        }
        expect(near(path, [45.9127, 28.2012])).toBeGreaterThan(150);
        const terminal = stopById(line(id).stops.at(-1)!);
        const end = direction === "outbound" ? path.at(-1)! : path[0]!;
        expect(haversine(end, [terminal.lat, terminal.lng])).toBeLessThan(35);
      }
    }
    const veche = stopById("veche147");
    expect(near(routePath(line("5")), [veche.lat, veche.lng])).toBeGreaterThan(100);
  });

  it("restores every route 2 stop and both municipal endpoints", () => {
    const l = line("2");
    expect(l.stops).toEqual([
      "chiliei",
      "scm104",
      "pat8",
      "scm42",
      "scm24",
      "indep3",
      "garaauto",
      "doin36",
      "nufalb",
      "necev",
    ]);
    for (const direction of ["outbound", "inbound"] as const) {
      const p = routePath(l, direction);
      const ids = routeStops(l, direction);
      for (const [point, id] of [
        [p[0]!, ids[0]!],
        [p.at(-1)!, ids.at(-1)!],
      ] as [P, string][]) {
        const s = stopById(id);
        expect(haversine(point, [s.lat, s.lng])).toBeLessThan(50);
      }
    }
  });

  it("runs route 6 on Stefan cel Mare to Poncik and returns along Alecsandri", () => {
    const l = line("6");
    expect(routeStops(l).at(-1)).toBe("spirin49");
    expect(routeStops(l)[0]).toBe("mv-sanat");
    expect(routeStops(l, "inbound").slice(0, 3)).toEqual(["spirin49", "chiliei", "alecsandri"]);
    expect(routeStops(l, "inbound").at(-1)).toBe("mv-sanat");
    expect(l.stops).not.toContain("pat8");
    expect(near(routePath(l), [45.913324, 28.2067862])).toBeGreaterThan(150);
    expect(near(routePath(l), [45.9127, 28.2012])).toBeGreaterThan(150);
    for (const p of corrections["1"].streetCorridor as P[]) {
      if (p[0] <= stopById("scm122").lat) expect(near(routePath(l), p)).toBeLessThan(45);
    }
    for (const p of [
      [45.9206722, 28.1951494],
      [45.9211763, 28.194489],
      [45.9146931, 28.1923188],
      [45.9123975, 28.1912188],
    ] as P[]) {
      expect(near(routePath(l, "inbound"), p)).toBeLessThan(35);
    }
    for (const direction of ["outbound", "inbound"] as const) {
      const p = routePath(l, direction);
      const ids = routeStops(l, direction);
      for (const [point, id] of [
        [p[0]!, ids[0]!],
        [p.at(-1)!, ids.at(-1)!],
      ] as [P, string][]) {
        const s = stopById(id);
        expect(haversine(point, [s.lat, s.lng])).toBeLessThan(35);
      }
    }
    const s = stopById("busuioc");
    expect(etaMinutes(l, [s.lat, s.lng], s.id)).not.toBeNull();
  });

  it("takes route 8 through Sanatoriului 2a and ends on Sfatul Tarii", () => {
    const l = line("8");
    expect(l.stops).toEqual(["cart15", "scm24", "indep3", "garaauto", "sanat2a", "sfatul"]);
    for (const direction of ["outbound", "inbound"] as const) {
      const p = routePath(l, direction);
      expect(near(p, [45.897769, 28.2080893])).toBeLessThan(35);
      const end = direction === "outbound" ? p.at(-1)! : p[0]!;
      const s = stopById("sfatul");
      expect(haversine(end, [s.lat, s.lng])).toBeLessThan(35);
    }
  });

  it("traverses both directions in the vehicle loop", () => {
    for (const l of LINES) {
      const loop = loopPath(l);
      expect(loop.pts.slice(routePath(l).length)).toEqual(routePath(l, "inbound"));
      expect(loop.total).toBeGreaterThan(loop.half);
      expect(pointAt(l, loop.total)).toEqual(pointAt(l, 0));
    }
  });
});
