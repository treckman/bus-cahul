import { useEffect, useState, type FormEvent } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export function useAccount() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    let revision = 0;
    const initialRevision = revision;
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      revision++;
      if (active) {
        setUser(session?.user ?? null);
        setLoading(false);
        setError("");
      }
    });
    supabase.auth
      .getSession()
      .then(({ data, error }) => {
        if (!active || revision !== initialRevision) return;
        setUser(data.session?.user ?? null);
        setError(error ? "Nu am putut verifica autentificarea. Reîncarcă pagina." : "");
        setLoading(false);
      })
      .catch(() => {
        if (active && revision === initialRevision) {
          setError("Nu am putut verifica autentificarea. Reîncarcă pagina.");
          setLoading(false);
        }
      });
    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);
  return { user, loading, error };
}

function authMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "";
  if (/expired|invalid.*token|otp/i.test(message))
    return "Codul nu este valid sau a expirat. Solicită un cod nou.";
  if (/rate|too many|seconds|limit/i.test(message))
    return "Prea multe încercări. Așteaptă un minut și încearcă din nou.";
  return "Autentificarea nu a reușit. Verifică internetul și încearcă din nou.";
}

export function Account({ user, loading, error }: ReturnType<typeof useAccount>) {
  const [email, setEmail] = useState("");
  const [sentTo, setSentTo] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [retryAt, setRetryAt] = useState(0);
  const [now, setNow] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const remaining = Math.max(0, Math.ceil((retryAt - now) / 1000));
  async function sendCode(event?: FormEvent) {
    event?.preventDefault();
    const target = email.trim().toLowerCase();
    if (busy || remaining || !target) return;
    setBusy(true);
    setStatus("");
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: target,
        options: { emailRedirectTo: window.location.origin + "/" },
      });
      if (error) throw error;
      setSentTo(target);
      setToken("");
      setRetryAt(Date.now() + 60000);
      setNow(Date.now());
      setStatus(
        "Verifică emailul, inclusiv Spam. Introdu codul primit sau deschide linkul de conectare din mesaj.",
      );
    } catch (error) {
      setStatus(authMessage(error));
    } finally {
      setBusy(false);
    }
  }
  async function verify(event: FormEvent) {
    event.preventDefault();
    if (busy || !sentTo || !/^\d{6,8}$/.test(token)) return;
    setBusy(true);
    setStatus("");
    try {
      const { error } = await supabase.auth.verifyOtp({ email: sentTo, token, type: "email" });
      if (error) throw error;
      setStatus("Te-ai conectat cu succes.");
      setToken("");
    } catch (error) {
      setStatus(authMessage(error));
    } finally {
      setBusy(false);
    }
  }
  async function logout() {
    setBusy(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setStatus("");
      setSentTo("");
      setToken("");
    } catch {
      setStatus("Deconectarea nu a reușit. Încearcă din nou.");
    } finally {
      setBusy(false);
    }
  }
  const input = "w-full rounded-xl border-2 border-input bg-card px-4 py-3 text-lg";
  return (
    <div className="mx-auto h-full max-w-lg space-y-5 overflow-y-auto p-5">
      <h2 className="text-2xl font-extrabold">Conectare șofer</h2>
      <p className="text-muted-foreground">
        Pasagerii folosesc harta, orarele și favoritele fără cont. Conectarea este necesară doar
        pentru a transmite poziția unei rutiere.
      </p>
      {loading ? (
        <p role="status">Se verifică autentificarea…</p>
      ) : user ? (
        <section className="space-y-4 rounded-2xl border-2 bg-card p-4">
          <p className="break-all text-lg font-bold">{user.email ?? "Cont conectat"}</p>
          <button
            disabled={busy}
            onClick={logout}
            className="min-h-12 rounded-xl bg-muted px-4 font-bold disabled:opacity-50"
          >
            Deconectează-te
          </button>
        </section>
      ) : (
        <>
          <form onSubmit={sendCode} className="space-y-3">
            <label className="block">
              <span className="mb-2 block font-bold">Adresa de email</span>
              <input
                type="email"
                autoComplete="email"
                required
                maxLength={254}
                value={email}
                disabled={busy || !!sentTo}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nume@exemplu.md"
                className={input}
              />
            </label>
            {!sentTo && (
              <button
                disabled={busy || remaining > 0}
                className="min-h-14 w-full rounded-xl bg-primary px-4 text-lg font-bold text-primary-foreground disabled:opacity-50"
              >
                {busy ? "Se trimite…" : "Trimite codul"}
              </button>
            )}
          </form>
          {sentTo && (
            <form onSubmit={verify} className="space-y-3">
              <p className="break-all">
                Mesaj trimis la <b>{sentTo}</b>
              </p>
              <label className="block">
                <span className="mb-2 block font-bold">Codul din email</span>
                <input
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  pattern="[0-9]{6,8}"
                  minLength={6}
                  maxLength={8}
                  required
                  value={token}
                  disabled={busy}
                  onChange={(e) => setToken(e.target.value.replace(/\D/g, ""))}
                  className={input}
                />
              </label>
              <button
                disabled={busy}
                className="min-h-14 w-full rounded-xl bg-primary px-4 text-lg font-bold text-primary-foreground disabled:opacity-50"
              >
                {busy ? "Se verifică…" : "Conectează-te"}
              </button>
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  disabled={busy || remaining > 0}
                  onClick={() => sendCode()}
                  className="min-h-12 rounded-lg bg-muted px-3 font-bold disabled:opacity-50"
                >
                  {remaining ? `Retrimite în ${remaining}s` : "Retrimite codul"}
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setSentTo("");
                    setToken("");
                    setStatus("");
                  }}
                  className="min-h-12 rounded-lg bg-muted px-3 font-bold"
                >
                  Schimbă emailul
                </button>
              </div>
            </form>
          )}
        </>
      )}
      {(status || error) && (
        <p role="status" className="rounded-xl bg-muted p-3">
          {status || error}
        </p>
      )}
    </div>
  );
}
