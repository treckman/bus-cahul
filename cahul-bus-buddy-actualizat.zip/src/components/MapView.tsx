import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { LocateFixed, Maximize, ExternalLink, LoaderCircle } from "lucide-react";
import type * as LT from "leaflet";
import {
  CAHUL_CENTER,
  LINES,
  STOPS,
  MAPPED_STOPS,
  stopById,
  routePath,
  routeStops,
  lineById,
} from "@/lib/transit";
import type { Direction } from "@/lib/schedule";
import { PLACES, placeById, googlePlaceUrl, googleCoordinateUrl } from "@/lib/places";
import { CAHUL_SERVICE_AREA, MAP_WORLD } from "@/lib/service-area";

export type Vehicle = { id: string; line: string; lat: number; lng: number; driver_name: string };

export type MapProps = {
  vehicles: Vehicle[];
  selectedStop: string | null;
  onSelectStop: (id: string) => void;
  filter: string;
  direction?: Direction;
  showMappedStops?: boolean;
  selectedPlace?: string | null;
  showPlaces?: boolean;
};

const GoogleMapsView = lazy(() =>
  import("./GoogleMapsView").then((module) => ({ default: module.GoogleMapsView })),
);

export function MapView(props: MapProps) {
  const key = import.meta.env["VITE_GOOGLE_MAPS_API_KEY"]?.trim();
  const [failed, setFailed] = useState(false);
  if (key && !failed)
    return (
      <Suspense
        fallback={
          <p role="status" className="p-4">
            Se încarcă Google Maps…
          </p>
        }
      >
        <GoogleMapsView {...props} apiKey={key} onError={() => setFailed(true)} />
      </Suspense>
    );
  return (
    <div className="relative h-full w-full">
      <LeafletMapView {...props} />
      {failed && (
        <p
          role="status"
          className="absolute left-14 top-2 z-[500] max-w-64 rounded-xl bg-card p-2 text-sm shadow"
        >
          Google Maps nu este disponibil. Este afișată harta OpenStreetMap.
        </p>
      )}
    </div>
  );
}

function LeafletMapView({
  vehicles,
  selectedStop,
  onSelectStop,
  filter,
  direction = "outbound",
  showMappedStops = true,
  selectedPlace = null,
  showPlaces = true,
}: MapProps) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<LT.Map | null>(null);
  const L = useRef<typeof LT | null>(null);
  const routesLayer = useRef<LT.LayerGroup | null>(null);
  const stopsLayer = useRef<LT.LayerGroup | null>(null);
  const vLayer = useRef<LT.LayerGroup | null>(null);
  const cb = useRef(onSelectStop);
  cb.current = onSelectStop;
  const ready = useRef(false);
  const locationLayer = useRef<LT.LayerGroup | null>(null);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState("");
  const locationRequest = useRef(0);
  const placesLayer = useRef<LT.LayerGroup | null>(null);
  const placesRef = useRef(() => {});
  placesRef.current = () => {
    const Lf = L.current,
      m = map.current,
      layer = placesLayer.current;
    if (!Lf || !m || !layer) return;
    layer.clearLayers();
    if (!showPlaces) return;
    const bounds = m.getBounds();
    PLACES.filter(
      (p) => (m.getZoom() >= 15 && bounds.contains([p.lat, p.lng])) || p.id === selectedPlace,
    ).forEach((p) => {
      const content = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = p.name;
      content.append(title);
      if (p.address) {
        const address = document.createElement("p");
        address.textContent = p.address;
        content.append(address);
      }
      const link = document.createElement("a");
      link.textContent = "Deschide în Google Maps";
      link.href = googlePlaceUrl(p);
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      content.append(link);
      const label = document.createElement("span");
      label.textContent = p.name;
      Lf.circleMarker([p.lat, p.lng], {
        radius: p.id === selectedPlace ? 9 : 4,
        color: "#7c3aed",
        weight: 2,
        fillColor: "white",
        fillOpacity: 1,
      })
        .bindTooltip(label, {
          permanent: m.getZoom() >= 17 || p.id === selectedPlace,
          direction: "top",
          className: "place-label",
        })
        .bindPopup(content)
        .addTo(layer);
    });
  };

  function locate() {
    if (!navigator.geolocation) {
      setLocationError("Localizarea nu este disponibilă pe acest dispozitiv.");
      return;
    }
    if (locating) return;
    const request = ++locationRequest.current;
    setLocating(true);
    setLocationError("");
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        if (request !== locationRequest.current) return;
        setLocating(false);
        const m = map.current,
          Lf = L.current,
          layer = locationLayer.current;
        if (!m || !Lf || !layer) return;
        layer.clearLayers();
        const position: [number, number] = [coords.latitude, coords.longitude];
        Lf.circle(position, {
          radius: coords.accuracy,
          color: "#2563eb",
          weight: 1,
          fillOpacity: 0.12,
        }).addTo(layer);
        Lf.circleMarker(position, {
          radius: 8,
          color: "white",
          weight: 3,
          fillColor: "#2563eb",
          fillOpacity: 1,
        })
          .bindTooltip("Ești aici")
          .addTo(layer);
        m.setView(position, 16);
      },
      (error) => {
        if (request !== locationRequest.current) return;
        setLocating(false);
        setLocationError(
          error.code === 1
            ? "Permite accesul la locație în browser pentru a te vedea pe hartă."
            : "Nu am putut afla locația. Încearcă din nou.",
        );
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 },
    );
  }

  const draw = () => {
    const Lf = L.current,
      m = map.current;
    if (!Lf || !m || !routesLayer.current || !stopsLayer.current || !vLayer.current) return;
    routesLayer.current.clearLayers();
    stopsLayer.current.clearLayers();
    vLayer.current.clearLayers();
    const all = filter === "all";
    LINES.forEach((l) => {
      const on = all || l.id === filter;
      if (!on) return;
      if (on)
        Lf.polyline(routePath(l, direction), {
          color: "#ffffff",
          weight: all ? 8 : 11,
          opacity: 0.9,
        }).addTo(routesLayer.current!);
      Lf.polyline(routePath(l, direction), {
        color: l.color,
        weight: on ? (all ? 5 : 7) : 3,
        opacity: on ? 0.95 : 0.15,
      })
        .bindTooltip(
          `Ruta ${l.id} · ${direction === "outbound" ? "Tur" : "Retur"} · traseu reconstruit`,
          { sticky: true },
        )
        .addTo(routesLayer.current!);
      if (!all) {
        const path = routePath(l, direction);
        // Sparse arrows show travel direction without covering street names.
        const stride = Math.max(1, Math.floor(path.length / 10));
        for (let i = stride; i < path.length - 1; i += stride) {
          const a = path[i - 1]!,
            b = path[i + 1]!;
          const angle =
            (Math.atan2((b[1] - a[1]) * Math.cos((a[0] * Math.PI) / 180), b[0] - a[0]) * 180) /
            Math.PI;
          Lf.marker(path[i]!, {
            interactive: false,
            icon: Lf.divIcon({
              className: "",
              iconSize: [20, 20],
              iconAnchor: [10, 10],
              html: `<div style="transform:rotate(${angle}deg);color:white;text-shadow:0 1px 3px ${l.color};font:bold 20px/20px sans-serif">↑</div>`,
            }),
          }).addTo(routesLayer.current!);
        }
      }
    });
    const visibleStops = all
      ? STOPS.filter((s) => LINES.some((l) => routeStops(l, direction).includes(s.id)))
      : routeStops(lineById(filter), direction).map(stopById);
    if (
      selectedStop &&
      !selectedStop.startsWith("osm-") &&
      !visibleStops.some((s) => s.id === selectedStop)
    )
      visibleStops.push(stopById(selectedStop));
    if (showMappedStops)
      MAPPED_STOPS.forEach((s) => {
        const content = document.createElement("span");
        content.textContent = `${s.name} · stație OpenStreetMap`;
        Lf.circleMarker([s.lat, s.lng], {
          radius: s.id === selectedStop ? 12 : 6,
          color: "#475569",
          weight: 2,
          fillColor: s.id === selectedStop ? "#ffc400" : "#cbd5e1",
          fillOpacity: 1,
        })
          .bindTooltip(content)
          .on("click", () => cb.current(s.id))
          .addTo(stopsLayer.current!);
      });
    visibleStops.forEach((s, i) => {
      const sel = s.id === selectedStop;
      const color = all ? "#0b1d3a" : lineById(filter).color;
      if (!all) {
        const label = document.createElement("span");
        label.textContent = `${i + 1}. ${s.name}`;
        Lf.marker([s.lat, s.lng], {
          icon: Lf.divIcon({
            className: "",
            iconSize: [26, 26],
            iconAnchor: [13, 13],
            html: `<div class="route-stop-number" style="background:${sel ? "#2563eb" : color}">${i + 1}</div>`,
          }),
          zIndexOffset: sel ? 900 : 500,
        })
          .bindTooltip(label)
          .on("click", () => cb.current(s.id))
          .addTo(stopsLayer.current!);
        return;
      }
      Lf.circleMarker([s.lat, s.lng], {
        radius: sel ? 13 : all ? 8 : 10,
        color,
        weight: 3,
        fillColor: sel ? "#ffc400" : "#ffffff",
        fillOpacity: 1,
      })
        .bindTooltip(all ? s.name : `${i + 1}. ${s.name}`, {
          direction: "top",
          offset: [0, -8],
          permanent: !all && visibleStops.length <= 12 && sel,
        })
        .on("click", () => cb.current(s.id))
        .addTo(stopsLayer.current!);
    });
    vehicles
      .filter((v) => all || v.line === filter)
      .forEach((v) => {
        if (
          !LINES.some((l) => l.id === v.line) ||
          !Number.isFinite(v.lat) ||
          !Number.isFinite(v.lng)
        )
          return;
        const color = LINES.some((l) => l.id === v.line) ? lineById(v.line).color : "#333";
        const icon = Lf.divIcon({
          className: "",
          iconSize: [40, 40],
          iconAnchor: [20, 20],
          html: `<div style="width:40px;height:40px;border-radius:12px;background:${color};color:#fff;font:800 20px/34px sans-serif;text-align:center;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.4)">${v.line}</div>`,
        });
        const label = document.createElement("span");
        label.textContent = `Ruta ${v.line}`;
        Lf.marker([v.lat, v.lng], { icon, zIndexOffset: 1000 })
          .bindTooltip(label)
          .addTo(vLayer.current!);
      });
  };
  const drawRef = useRef(draw);
  drawRef.current = draw;
  const fitRef = useRef(() => {});
  fitRef.current = () => {
    const m = map.current,
      Lf = L.current;
    if (!m || !Lf) return;
    const place = selectedPlace ? placeById(selectedPlace) : undefined;
    if (place) {
      m.setView([place.lat, place.lng], 17);
    } else if (selectedStop) {
      const stop = stopById(selectedStop);
      m.setView([stop.lat, stop.lng], Math.max(m.getZoom(), 16));
    } else if (filter === "all") m.setView(CAHUL_CENTER, 14);
    else
      m.fitBounds(Lf.latLngBounds(routePath(lineById(filter), direction)), {
        padding: [30, 30],
        animate: false,
      });
  };

  useEffect(() => {
    let cancelled = false;
    const requestRef = locationRequest;
    let resizeObserver: ResizeObserver | undefined;
    let resizeTimer: ReturnType<typeof setTimeout> | undefined;
    import("leaflet").then((mod) => {
      if (cancelled || !el.current || map.current) return;
      const Lf = (mod.default ?? mod) as typeof LT;
      L.current = Lf;
      const m = Lf.map(el.current).setView(CAHUL_CENTER, 14);
      m.attributionControl.setPrefix(false);
      m.attributionControl.setPosition("bottomleft");
      Lf.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(m);
      m.createPane("serviceArea").style.zIndex = "350";
      Lf.polygon([MAP_WORLD, CAHUL_SERVICE_AREA], {
        pane: "serviceArea",
        stroke: false,
        fillColor: "#111827",
        fillOpacity: 0.65,
        fillRule: "evenodd",
        interactive: false,
      }).addTo(m);
      routesLayer.current = Lf.layerGroup().addTo(m);
      stopsLayer.current = Lf.layerGroup().addTo(m);
      vLayer.current = Lf.layerGroup().addTo(m);
      locationLayer.current = Lf.layerGroup().addTo(m);
      placesLayer.current = Lf.layerGroup().addTo(m);
      m.on("moveend zoomend", () => placesRef.current());
      map.current = m;
      ready.current = true;
      drawRef.current();
      fitRef.current();
      placesRef.current();
      resizeTimer = setTimeout(() => m.invalidateSize(), 50);
      if (typeof ResizeObserver !== "undefined") {
        resizeObserver = new ResizeObserver(() => {
          m.stop();
          m.invalidateSize();
          fitRef.current();
        });
        resizeObserver.observe(el.current);
      }
    });
    return () => {
      cancelled = true;
      requestRef.current++;
      resizeObserver?.disconnect();
      clearTimeout(resizeTimer);
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    draw();
    placesRef.current();
  });

  // Încadrează ruta selectată
  useEffect(() => {
    fitRef.current();
  }, [filter, direction]);

  useEffect(() => {
    if (!selectedStop || !map.current) return;
    const stop = stopById(selectedStop);
    map.current.setView([stop.lat, stop.lng], Math.max(map.current.getZoom(), 16));
  }, [selectedStop]);

  useEffect(() => {
    if (selectedPlace) fitRef.current();
  }, [selectedPlace]);

  return (
    <div className="relative h-full w-full">
      <div
        ref={el}
        className="h-full w-full"
        aria-label="Harta colorată a transportului din Cahul"
      />
      <div className="map-tools absolute bottom-6 right-3 z-[500] flex flex-col items-end gap-2">
        <a
          href={
            selectedPlace && placeById(selectedPlace)
              ? googlePlaceUrl(placeById(selectedPlace)!)
              : googleCoordinateUrl(
                  selectedStop ? stopById(selectedStop).lat : CAHUL_CENTER[0],
                  selectedStop ? stopById(selectedStop).lng : CAHUL_CENTER[1],
                )
          }
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Deschide în Google Maps"
          title="Deschide în Google Maps"
          className="map-tool"
        >
          <ExternalLink size={19} />
        </a>
        {locationError && (
          <p role="status" className="max-w-64 rounded-xl bg-card p-3 text-sm shadow-lg">
            {locationError}
          </p>
        )}
        <button
          onClick={() => fitRef.current()}
          aria-label="Încadrează ruta"
          title="Încadrează ruta"
          className="map-tool"
        >
          <Maximize size={19} />
        </button>
        <button
          disabled={locating}
          onClick={locate}
          aria-label="Locația mea"
          title="Locația mea"
          className="map-tool disabled:opacity-60"
        >
          {locating ? (
            <LoaderCircle size={19} className="animate-spin" />
          ) : (
            <LocateFixed size={19} />
          )}
        </button>
      </div>
    </div>
  );
}
