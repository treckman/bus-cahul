import { useEffect, useRef, useState } from "react";
import type { MapProps } from "./MapView";
import {
  CAHUL_CENTER,
  LINES,
  STOPS,
  MAPPED_STOPS,
  routePath,
  routeStops,
  lineById,
  stopById,
} from "@/lib/transit";
import { placeById, googleCoordinateUrl } from "@/lib/places";
import { CAHUL_SERVICE_AREA, MAP_WORLD } from "@/lib/service-area";
import {
  loadGoogleMaps,
  type GoogleMap,
  type GoogleMaps,
  type Coordinates,
} from "@/lib/google-maps";

const point = ([lat, lng]: [number, number]): Coordinates => ({ lat, lng });

export function GoogleMapsView(props: MapProps & { apiKey: string; onError: () => void }) {
  const container = useRef<HTMLDivElement>(null);
  const runtime = useRef<GoogleMaps | null>(null);
  const map = useRef<GoogleMap | null>(null);
  const overlays = useRef<Array<{ setMap(map: GoogleMap | null): void }>>([]);
  const markers = useRef<Array<{ map: GoogleMap | null }>>([]);
  const location = useRef<{ setMap(map: GoogleMap | null): void } | null>(null);
  const current = useRef(props);
  current.current = props;
  const [ready, setReady] = useState(false);
  const [locating, setLocating] = useState(false);
  const [status, setStatus] = useState("");
  const request = useRef(0);
  const fit = useRef(() => {});
  fit.current = () => {
    const m = map.current,
      g = runtime.current,
      p = current.current;
    if (!m || !g) return;
    const place = p.selectedPlace ? placeById(p.selectedPlace) : undefined;
    if (place) {
      m.setCenter({ lat: place.lat, lng: place.lng });
      m.setZoom(17);
    } else if (p.selectedStop) {
      const stop = stopById(p.selectedStop);
      m.setCenter({ lat: stop.lat, lng: stop.lng });
      m.setZoom(17);
    } else if (p.filter === "all") {
      m.setCenter(point(CAHUL_CENTER));
      m.setZoom(15);
    } else {
      const bounds = new g.LatLngBounds();
      routePath(lineById(p.filter), p.direction).forEach((p) => bounds.extend(point(p)));
      m.fitBounds(bounds, 30);
    }
  };
  useEffect(() => {
    let disposed = false;
    const requestRef = request;
    let observer: ResizeObserver | undefined;
    const fail = () => current.current.onError();
    window.addEventListener("cahul-google-map-error", fail);
    loadGoogleMaps(current.current.apiKey)
      .then((g) => {
        if (disposed || !container.current) return;
        runtime.current = g;
        map.current = new g.Map(container.current, {
          center: point(CAHUL_CENTER),
          zoom: 15,
          mapId: import.meta.env["VITE_GOOGLE_MAPS_MAP_ID"] || "DEMO_MAP_ID",
          mapTypeId: "roadmap",
          clickableIcons: true,
          streetViewControl: false,
          fullscreenControl: false,
          mapTypeControl: true,
          gestureHandling: "greedy",
        });
        if (typeof ResizeObserver !== "undefined") {
          observer = new ResizeObserver(() => fit.current());
          observer.observe(container.current);
        }
        setReady(true);
      })
      .catch(() => {
        if (!disposed) fail();
      });
    return () => {
      disposed = true;
      requestRef.current++;
      observer?.disconnect();
      window.removeEventListener("cahul-google-map-error", fail);
      overlays.current.forEach((o) => o.setMap(null));
      markers.current.forEach((marker) => {
        runtime.current?.event.clearInstanceListeners(marker);
        marker.map = null;
      });
      location.current?.setMap(null);
      if (map.current) runtime.current?.event.clearInstanceListeners(map.current);
      map.current = null;
    };
  }, []);
  useEffect(() => {
    const m = map.current,
      g = runtime.current;
    if (!ready || !m || !g) return;
    overlays.current.forEach((o) => o.setMap(null));
    overlays.current = [];
    overlays.current.push(
      new g.Polygon({
        map: m,
        paths: [MAP_WORLD.map(point), CAHUL_SERVICE_AREA.map(point)],
        strokeWeight: 0,
        fillColor: "#111827",
        fillOpacity: 0.65,
        clickable: false,
        zIndex: -1,
      }),
    );
    markers.current.forEach((marker) => {
      g.event.clearInstanceListeners(marker);
      marker.map = null;
    });
    markers.current = [];
    const all = props.filter === "all";
    const lines = LINES.filter((l) => all || l.id === props.filter);
    lines.forEach((line) => {
      const path = routePath(line, props.direction).map(point);
      overlays.current.push(
        new g.Polyline({
          map: m,
          path,
          strokeColor: "white",
          strokeWeight: all ? 7 : 10,
          strokeOpacity: 0.9,
        }),
      );
      overlays.current.push(
        new g.Polyline({
          map: m,
          path,
          strokeColor: line.color,
          strokeWeight: all ? 4 : 6,
          icons: all
            ? []
            : [
                {
                  icon: { path: g.SymbolPath.FORWARD_CLOSED_ARROW, scale: 2, strokeColor: "white" },
                  offset: "40px",
                  repeat: "140px",
                },
              ],
        }),
      );
    });
    const ordered = all
      ? STOPS.filter((s) => lines.some((l) => routeStops(l, props.direction).includes(s.id)))
      : routeStops(lines[0]!, props.direction).map(stopById);
    const stops = [...ordered, ...(props.showMappedStops ? MAPPED_STOPS : [])];
    if (props.selectedStop && !stops.some((s) => s.id === props.selectedStop))
      stops.push(stopById(props.selectedStop));
    stops.forEach((s, index) => {
      const content = document.createElement("div");
      content.className = "google-stop";
      content.textContent = all || index >= ordered.length ? "●" : String(index + 1);
      content.style.background =
        s.id === props.selectedStop ? "#2563eb" : all ? "#0b1d3a" : lines[0]!.color;
      const marker = new g.marker.AdvancedMarkerElement({
        map: m,
        position: { lat: s.lat, lng: s.lng },
        content,
        title: s.name,
      });
      marker.addListener("click", () => current.current.onSelectStop(s.id));
      markers.current.push(marker);
    });
    props.vehicles
      .filter(
        (v) =>
          lines.some((l) => l.id === v.line) && Number.isFinite(v.lat) && Number.isFinite(v.lng),
      )
      .forEach((v) => {
        const content = document.createElement("div");
        content.className = "google-vehicle";
        content.textContent = v.line;
        content.style.background = lineById(v.line).color;
        markers.current.push(
          new g.marker.AdvancedMarkerElement({
            map: m,
            position: { lat: v.lat, lng: v.lng },
            content,
            title: `Ruta ${v.line}`,
            zIndex: 1000,
          }),
        );
      });
  }, [
    ready,
    props.filter,
    props.direction,
    props.selectedStop,
    props.showMappedStops,
    props.vehicles,
  ]);
  useEffect(() => {
    if (ready) fit.current();
  }, [ready, props.filter, props.direction, props.selectedStop, props.selectedPlace]);

  function locate() {
    if (!navigator.geolocation) {
      setStatus("Localizarea nu este disponibilă.");
      return;
    }
    if (locating) return;
    const generation = ++request.current;
    setLocating(true);
    setStatus("");
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        if (generation !== request.current) return;
        setLocating(false);
        const g = runtime.current,
          m = map.current;
        if (!g || !m) return;
        const center = { lat: coords.latitude, lng: coords.longitude };
        location.current?.setMap(null);
        location.current = new g.Circle({
          map: m,
          center,
          radius: Math.max(coords.accuracy, 8),
          fillColor: "#2563eb",
          fillOpacity: 0.3,
          strokeColor: "#2563eb",
          strokeWeight: 2,
        });
        m.setCenter(center);
        m.setZoom(17);
      },
      (error) => {
        if (generation !== request.current) return;
        setLocating(false);
        setStatus(
          error.code === 1
            ? "Permite accesul la locație în browser."
            : "Nu am putut afla locația. Încearcă din nou.",
        );
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 },
    );
  }
  return (
    <div className="relative h-full w-full">
      <div
        ref={container}
        className="h-full w-full"
        aria-label="Google Maps — transport public Cahul"
      />
      {!ready && (
        <p role="status" className="absolute inset-0 grid place-items-center bg-card">
          Se încarcă Google Maps…
        </p>
      )}
      <div className="absolute bottom-12 right-3 z-[500] flex flex-col items-end gap-2">
        {status && (
          <p role="status" className="max-w-64 rounded-xl bg-card p-3 text-sm shadow">
            {status}
          </p>
        )}
        <a
          href={googleCoordinateUrl(CAHUL_CENTER[0], CAHUL_CENTER[1])}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-xl bg-card px-3 py-2 text-sm font-bold shadow"
        >
          Google Maps ↗
        </a>
        <button
          onClick={() => fit.current()}
          className="min-h-11 rounded-xl bg-card px-3 text-sm font-bold shadow"
        >
          Încadrează ruta
        </button>
        <button
          disabled={!ready || locating}
          onClick={locate}
          className="min-h-11 rounded-xl bg-primary px-3 text-sm font-bold text-primary-foreground shadow"
        >
          {locating ? "Se caută…" : "◎ Locația mea"}
        </button>
      </div>
    </div>
  );
}
