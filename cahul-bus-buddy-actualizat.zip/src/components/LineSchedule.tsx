import { useState } from "react";
import { servicesForLine, TRANSPORT_SCHEDULE, type Direction } from "@/lib/schedule";
import { lineById, stopById } from "@/lib/transit";

export function LineSchedule({ lineId }: { lineId: string }) {
  const [direction, setDirection] = useState<Direction>("outbound");
  const [code, setCode] = useState("all");
  const services = servicesForLine(lineId);
  const line = lineById(lineId);
  const rows = services
    .filter((service) => code === "all" || service.code === code)
    .flatMap((service) => service.trips.map((trip) => ({ ...trip, code: service.code })))
    .map((trip) => ({
      ...trip,
      departure: direction === "outbound" ? trip.outboundDeparture : trip.inboundDeparture,
      arrival: direction === "outbound" ? trip.outboundArrival : trip.inboundArrival,
    }))
    .filter((trip) => trip.departure)
    .sort((a, b) => a.departure!.localeCompare(b.departure!) || a.code.localeCompare(b.code));
  const firstStop = services[0]?.from.replace(/\s+/g, " ") ?? stopById(line.stops[0]!).name;
  const lastStop =
    services[0]?.to.replace(/\s+/g, " ") ?? stopById(line.stops[line.stops.length - 1]!).name;
  return (
    <details className="rounded-xl border bg-background p-3">
      <summary className="cursor-pointer text-lg font-bold">
        Orarul din documentul Primăriei · {services.length}{" "}
        {services.length === 1 ? "cursă" : "curse"}
      </summary>
      <div className="mt-4 space-y-4">
        <div className="grid grid-cols-2 gap-2" aria-label="Sensul orarului">
          {(["outbound", "inbound"] as Direction[]).map((value) => (
            <button
              key={value}
              aria-pressed={direction === value}
              onClick={() => setDirection(value)}
              className={`min-h-12 rounded-xl px-3 font-bold ${direction === value ? "bg-secondary text-secondary-foreground" : "bg-muted"}`}
            >
              {value === "outbound" ? "Tur" : "Retur"}
            </button>
          ))}
        </div>
        <p className="font-semibold">
          {direction === "outbound" ? firstStop : lastStop} →{" "}
          {direction === "outbound" ? lastStop : firstStop}
        </p>
        <label className="block">
          <span className="mb-2 block font-bold">Cursa numerotată</span>
          <select
            value={code}
            onChange={(event) => setCode(event.target.value)}
            className="min-h-12 w-full rounded-xl border-2 bg-card px-3"
          >
            <option value="all">Toate cursele liniei {lineId}</option>
            {services.map((service) => (
              <option key={service.code} value={service.code}>
                Cursa {service.code}
              </option>
            ))}
          </select>
        </label>
        <div className="max-h-80 overflow-auto rounded-lg border">
          <table className="w-full text-left tabular-nums">
            <thead className="sticky top-0 bg-secondary text-secondary-foreground">
              <tr>
                <th className="p-2">Cursa</th>
                <th className="p-2">Plecare</th>
                <th className="p-2">Sosire la capăt</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={`${row.code}-${index}`} className="border-t">
                  <td className="p-2">
                    {row.code}
                    {row.notes.length > 0 && (
                      <span title={row.notes.join(" ")} aria-label="Oră de confirmat în document">
                        {" "}
                        *
                      </span>
                    )}
                  </td>
                  <td className="p-2 font-bold">{row.departure}</td>
                  <td className="p-2">{row.arrival ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-sm text-muted-foreground">
          Ore transcrise din PDF, inclusiv neconcordanțele sursei. * Rând de confirmat cu
          operatorul. Orele reprezintă plecări și sosiri la capete, nu sosiri live în stațiile
          intermediare.
        </p>
        <a
          className="inline-block min-h-10 font-bold underline"
          href={TRANSPORT_SCHEDULE.sourceUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Consultă documentul Primăriei
        </a>
      </div>
    </details>
  );
}
