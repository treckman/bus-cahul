import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  LINES,
  ALL_STOPS,
  lineById,
  stopById,
  etaMinutes,
  pointAt,
  loopPath,
  routeStops,
} from "@/lib/transit";
import type { Direction } from "@/lib/schedule";
import type { Vehicle } from "@/components/MapView";
import { PLACES } from "@/lib/places";
import { Account, useAccount } from "@/components/Account";
import { LineSchedule } from "@/components/LineSchedule";
import type { User } from "@supabase/supabase-js";
import {
  Map,
  Clock,
  BusFront,
  Moon,
  Sun,
  Star,
  X,
  List,
  Smartphone,
  Monitor,
  Phone,
  Instagram,
  MapPin,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const MapView = lazy(() => import("@/components/MapView").then((m) => ({ default: m.MapView })));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CahulRutier — Rutierele din Cahul în timp real" },
      {
        name: "description",
        content:
          "Vezi pe hartă rutierele din Cahul, află în câte minute ajung la stație și consultă orarele liniilor.",
      },
      { property: "og:title", content: "CahulRutier — Transport public Cahul" },
      {
        property: "og:description",
        content:
          "Hartă în timp real a rutierelor, ETA la stații și orare pentru liniile din Cahul.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: App,
});

type Tab = "harta" | "linii" | "sofer";
const STALE_MS = 2 * 60 * 1000;

function useVehicles() {
  const [list, setList] = useState<(Vehicle & { updated_at: string })[]>([]);
  useEffect(() => {
    supabase
      .from("vehicles")
      .select("*")
      .then(({ data }) => data && setList(data));
    const ch = supabase
      .channel("vehicles-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "vehicles" }, (p) => {
        setList((prev) => {
          if (p.eventType === "DELETE")
            return prev.filter((v) => v.id !== (p.old as { id: string }).id);
          const row = p.new as Vehicle & { updated_at: string };
          return [...prev.filter((v) => v.id !== row.id), row];
        });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 15000);
    return () => clearInterval(t);
  }, []);
  return list.filter(
    (v) =>
      LINES.some((line) => line.id === v.line) && now - new Date(v.updated_at).getTime() < STALE_MS,
  );
}

function App() {
  const [tab, setTab] = useState<Tab>("harta");
  const [dark, setDark] = useState(false);
  const [filter, setFilter] = useState("all");
  const [layout, setLayout] = useState<"mobile" | "desktop">("desktop");
  const [chooseLayout, setChooseLayout] = useState(false);
  useEffect(() => {
    setDark(localStorage.getItem("cr-theme") === "dark");
    const saved = localStorage.getItem("cr-layout");
    if (saved === "mobile" || saved === "desktop") setLayout(saved);
    else {
      setLayout(window.innerWidth <= 600 ? "mobile" : "desktop");
      setChooseLayout(true);
    }
  }, []);
  function selectLayout(value: "mobile" | "desktop") {
    setLayout(value);
    localStorage.setItem("cr-layout", value);
    setChooseLayout(false);
  }
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("cr-theme", dark ? "dark" : "light");
  }, [dark]);
  const vehicles = useVehicles();
  const account = useAccount();

  return (
    <div
      data-layout={layout}
      className="transit-app flex min-h-[100dvh] flex-col bg-background text-foreground"
    >
      <header className="app-header">
        <h1 className="app-brand">
          <BusFront size={22} aria-hidden="true" /> CahulRutier
        </h1>
        <nav className="app-navigation" aria-label="Navigare principală">
          {(
            [
              ["harta", "Hartă", Map],
              ["linii", "Linii și orare", Clock],
              ["sofer", "Șofer", BusFront],
            ] as const
          ).map(([key, label, Icon]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              aria-current={tab === key ? "page" : undefined}
            >
              <Icon size={18} aria-hidden="true" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
        <button
          onClick={() => setChooseLayout(true)}
          aria-label="Alege telefon sau calculator"
          title="Telefon sau calculator"
          className="theme-button"
        >
          {layout === "mobile" ? <Smartphone size={18} /> : <Monitor size={18} />}
        </button>
        <button
          onClick={() => setDark(!dark)}
          aria-label="Schimbă tema"
          title="Schimbă tema"
          className="theme-button"
        >
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </button>
      </header>
      <main className="app-main relative overflow-hidden">
        <div className={tab === "harta" ? "h-full" : "hidden"}>
          <Passenger vehicles={vehicles} filter={filter} onFilter={setFilter} />
        </div>
        {tab === "linii" && (
          <Lines
            onView={(id) => {
              setFilter(id);
              setTab("harta");
            }}
          />
        )}
        {/* Șoferul rămâne montat ca să nu se oprească cursa la schimbarea filei */}
        <div className={tab === "sofer" ? "h-full" : "hidden"}>
          {account.user ? (
            <>
              <Driver
                user={account.user}
                loading={account.loading}
                onLogin={() => setTab("sofer")}
              />
              <button
                onClick={() => supabase.auth.signOut()}
                className="absolute right-3 top-3 rounded-xl bg-muted px-3 py-2 text-sm font-bold"
              >
                Deconectare
              </button>
            </>
          ) : (
            <Account {...account} />
          )}
        </div>
      </main>
      <footer className="about-section" aria-labelledby="about-title">
        <div className="about-inner">
          <div>
            <span className="about-brand">
              <BusFront size={20} aria-hidden="true" /> CahulRutier
            </span>
            <h2 id="about-title">Despre noi</h2>
            <p>
              Un proiect local pentru transportul din Cahul. Adunăm într-un singur loc rutele,
              opririle și orarele orașului.
            </p>
            <span className="about-location">
              <MapPin size={16} aria-hidden="true" /> or. Cahul, Moldova
            </span>
          </div>
          <div className="about-contacts">
            <h3>Contacte</h3>
            <div className="contact-columns">
              <div>
                {["alexbuac_803", "treck.man", "eugen00p", "dcappro"].map((handle) => (
                  <a
                    key={handle}
                    href={`https://www.instagram.com/${handle}/`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Instagram size={20} aria-hidden="true" />
                    <span>
                      <small>Instagram</small>@{handle}
                    </span>
                  </a>
                ))}
              </div>
              <div>
                {[
                  ["+37378804063", "+373 788 04 063"],
                  ["+37378085420", "+373 780 85 420"],
                  ["+37367618046", "+373 676 18 046"],
                  ["+37367781429", "+373 677 81 429"],
                ].map(([number, label]) => (
                  <a key={number} href={`tel:${number}`}>
                    <Phone size={20} aria-hidden="true" />
                    <span>
                      <small>Telefon</small>
                      {label}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
        <p className="about-bottom">CahulRutier · Cahul, Republica Moldova</p>
      </footer>
      <Dialog open={chooseLayout} onOpenChange={setChooseLayout}>
        <DialogContent className="device-dialog">
          <DialogHeader>
            <DialogTitle>Telefon sau calculator?</DialogTitle>
            <DialogDescription>Alege varianta potrivită pentru tine.</DialogDescription>
          </DialogHeader>
          <div className="device-options">
            <button onClick={() => selectLayout("mobile")}>
              <Smartphone size={38} strokeWidth={1.5} aria-hidden="true" />
              <span>Mobil</span>
            </button>
            <button onClick={() => selectLayout("desktop")}>
              <Monitor size={38} strokeWidth={1.5} aria-hidden="true" />
              <span>Calculator</span>
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function RouteFilter({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="route-filter" role="group" aria-label="Alege ruta">
      <button
        onClick={() => onChange("all")}
        aria-pressed={value === "all"}
        className="route-choice route-all"
      >
        Toate
      </button>
      {LINES.map((l) => (
        <button
          key={l.id}
          onClick={() => onChange(l.id)}
          aria-pressed={value === l.id}
          className="route-choice"
        >
          <span className="route-dot" style={{ background: l.color }} aria-hidden="true" />
          {l.id}
        </button>
      ))}
    </div>
  );
}

function Passenger({
  vehicles,
  filter,
  onFilter,
}: {
  vehicles: Vehicle[];
  filter: string;
  onFilter: (id: string) => void;
}) {
  const [stop, setStop] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  useEffect(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem("cr-favorites") ?? "[]");
      if (Array.isArray(saved))
        setFavorites(
          saved.filter(
            (id): id is string => typeof id === "string" && LINES.some((l) => l.id === id),
          ),
        );
    } catch {
      /* favorites are optional */
    }
  }, []);
  useEffect(() => {
    if (filter !== "all") {
      setSelectedPlace(null);
      setStop(null);
      setPanelOpen(false);
    }
  }, [filter]);
  function toggleFavorite(id: string) {
    const next = favorites.includes(id) ? favorites.filter((v) => v !== id) : [...favorites, id];
    setFavorites(next);
    localStorage.setItem("cr-favorites", JSON.stringify(next));
  }
  function selectStop(id: string) {
    setSelectedPlace(null);
    setStop(id);
    setPanelOpen(true);
  }
  const [direction, setDirection] = useState<Direction>("outbound");
  const [search, setSearch] = useState("");
  const [showMappedStops, setShowMappedStops] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<string | null>(null);
  const [showPlaces, setShowPlaces] = useState(true);
  const normalize = (value: string) =>
    value
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  const matches = search.trim()
    ? ALL_STOPS.filter((s) => normalize(s.name).includes(normalize(search.trim()))).slice(0, 8)
    : [];
  const matchingPlaces = search.trim()
    ? PLACES.filter((p) =>
        normalize(p.name + " " + p.address).includes(normalize(search.trim())),
      ).slice(0, 8)
    : [];
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const shown = vehicles.filter((v) => filter === "all" || v.line === filter);
  const arrivals = stop
    ? LINES.filter(
        (l) => routeStops(l, direction).includes(stop) && (filter === "all" || l.id === filter),
      ).map((l) => {
        const etas = vehicles
          .filter((v) => v.line === l.id)
          .map((v) => etaMinutes(l, [v.lat, v.lng], stop))
          .filter((x): x is number => x !== null)
          .sort((a, b) => a - b);
        return { line: l, etas };
      })
    : [];
  const fl = filter === "all" ? null : lineById(filter);
  return (
    <div className="passenger-view flex h-full flex-col">
      <RouteFilter
        value={filter}
        onChange={(v) => {
          onFilter(v);
          setSelectedPlace(null);
          setStop(null);
          setPanelOpen(false);
        }}
      />
      {favorites.length > 0 && (
        <div className="flex gap-2 overflow-x-auto bg-card px-3 pb-2">
          {favorites.map((id) => (
            <button
              key={id}
              onClick={() => {
                onFilter(id);
                setPanelOpen(false);
                setStop(null);
              }}
              className="min-h-9 shrink-0 rounded-full bg-muted px-3 text-sm font-bold"
            >
              ★ Ruta {id}
            </button>
          ))}
        </div>
      )}
      {fl && (
        <div className="selected-route">
          <span className="route-dot" style={{ background: fl.color }} aria-hidden="true" />
          <span className="selected-route-name">
            Ruta {fl.id} · {fl.name}
          </span>
          <button
            title="Opriri"
            aria-label="Arată opririle rutei"
            aria-expanded={panelOpen && !stop}
            onClick={() => {
              setStop(null);
              setPanelOpen(!panelOpen);
            }}
          >
            <List size={18} />
            <span>Opriri</span>
          </button>
          <button
            title="Favorite"
            aria-label={
              favorites.includes(fl.id) ? "Elimină ruta din favorite" : "Adaugă ruta la favorite"
            }
            aria-pressed={favorites.includes(fl.id)}
            onClick={() => toggleFavorite(fl.id)}
          >
            <Star size={18} fill={favorites.includes(fl.id) ? "currentColor" : "none"} />
          </button>
        </div>
      )}
      <div className="relative z-[600] space-y-2 bg-card px-3 pb-2">
        <input
          aria-label="Caută o stație sau un loc"
          placeholder="Caută o stație sau un loc"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="min-h-11 w-full rounded-xl border-2 bg-background px-3"
        />
        {search.trim() && (
          <div className="absolute left-3 right-3 top-12 max-h-56 overflow-auto rounded-xl border-2 bg-card shadow-xl">
            {matches.length
              ? matches.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      selectStop(s.id);
                      setSearch("");
                      if (s.id.startsWith("osm-")) setShowMappedStops(true);
                    }}
                    className="block min-h-12 w-full border-b px-3 py-2 text-left"
                  >
                    {s.name}
                    <span className="ml-2 text-xs text-muted-foreground">
                      {s.id.startsWith("osm-") ? "OSM" : "Program de transport"}
                    </span>
                  </button>
                ))
              : null}
            {matchingPlaces.map((place) => (
              <button
                key={place.id}
                onClick={() => {
                  setSelectedPlace(place.id);
                  setStop(null);
                  setSearch("");
                  setPanelOpen(false);
                  setShowPlaces(true);
                }}
                className="block min-h-12 w-full border-b px-3 py-2 text-left"
              >
                <span className="font-bold">{place.name}</span>
                <span className="ml-2 text-xs text-muted-foreground">
                  Loc · {place.address || "Cahul"}
                </span>
              </button>
            ))}
            {!matches.length && !matchingPlaces.length && (
              <p className="p-3">
                Niciun rezultat în datele disponibile.{" "}
                <a
                  className="underline"
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(search.trim() + ", Cahul, Moldova")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Caută în Google Maps ↗
                </a>
              </p>
            )}
          </div>
        )}
        <div className="flex flex-wrap items-center gap-2">
          <button
            aria-pressed={direction === "outbound"}
            onClick={() => setDirection("outbound")}
            className={`min-h-10 rounded-lg px-3 font-bold ${direction === "outbound" ? "bg-secondary text-secondary-foreground" : "bg-muted"}`}
          >
            Tur →
          </button>
          <button
            aria-pressed={direction === "inbound"}
            onClick={() => setDirection("inbound")}
            className={`min-h-10 rounded-lg px-3 font-bold ${direction === "inbound" ? "bg-secondary text-secondary-foreground" : "bg-muted"}`}
          >
            ← Retur
          </button>
          <label className="flex min-h-10 items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={showMappedStops}
              onChange={(e) => setShowMappedStops(e.target.checked)}
            />
            Toate stațiile
          </label>
          {!import.meta.env["VITE_GOOGLE_MAPS_API_KEY"] && (
            <label className="flex min-h-10 items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={showPlaces}
                onChange={(e) => setShowPlaces(e.target.checked)}
              />
              Magazine și locuri
            </label>
          )}
        </div>
      </div>
      <div className="relative min-h-36 flex-1">
        {mounted && (
          <Suspense fallback={<div className="p-6 text-lg">Se încarcă harta…</div>}>
            <MapView
              vehicles={vehicles}
              selectedStop={stop}
              onSelectStop={selectStop}
              filter={filter}
              direction={direction}
              showMappedStops={showMappedStops}
              selectedPlace={selectedPlace}
              showPlaces={showPlaces}
            />
          </Suspense>
        )}
        <div className="map-live-status pointer-events-none absolute right-2 top-2 z-[500] rounded-lg bg-card/95 px-3 py-2 text-xs font-medium shadow-sm">
          {shown.length ? `${shown.length} rutiere pe hartă` : "Fără poziții live disponibile"}
        </div>
      </div>
      {panelOpen && (
        <section className="stop-panel max-h-[40%] shrink-0 overflow-y-auto border-t bg-card p-4">
          {!stop ? (
            fl ? (
              <div>
                <div className="mb-2 flex items-center gap-3">
                  <LineBadge id={fl.id} />
                  <h2 className="flex-1 text-xl font-extrabold">{fl.name}</h2>
                  <button
                    onClick={() => setPanelOpen(false)}
                    aria-label="Închide detaliile rutei"
                    className="min-h-11 min-w-11 shrink-0 rounded-lg bg-muted px-3 py-2 text-lg font-bold"
                  >
                    <X size={18} />
                  </button>
                </div>
                <p className="mb-2 text-sm text-muted-foreground">
                  {direction === "outbound" ? "Tur" : "Retur"} ·{" "}
                  {stopById(routeStops(fl, direction).at(-1)!).name}
                </p>
                {
                  <>
                    <ol className="space-y-1">
                      {routeStops(fl, direction).map((s, i) => (
                        <li key={s}>
                          <button
                            onClick={() => selectStop(s)}
                            className="w-full rounded-lg px-2 py-2 text-left text-lg hover:bg-muted"
                          >
                            <b>{i + 1}.</b> {stopById(s).name}
                          </button>
                        </li>
                      ))}
                    </ol>
                    {fl.unlocatedStops?.map((s) => (
                      <p key={s} className="mt-2 px-2 text-sm text-muted-foreground">
                        {stopById(s).name} · poziție de confirmat
                      </p>
                    ))}
                  </>
                }
              </div>
            ) : (
              <p className="text-xl font-semibold">
                Alege o rută sus sau atinge o stație pe hartă pentru a vedea sosirile.
              </p>
            )
          ) : (
            <>
              <div className="mb-3 flex items-center justify-between gap-2">
                <h2 className="text-2xl font-extrabold">{stopById(stop).name}</h2>
                <button
                  onClick={() => {
                    setStop(null);
                    setPanelOpen(false);
                  }}
                  aria-label="Închide"
                  className="rounded-lg bg-muted px-3 py-2 text-lg font-bold"
                >
                  ✕
                </button>
              </div>
              <ul className="space-y-2">
                {arrivals.map(({ line, etas }) => (
                  <li key={line.id} className="flex items-center gap-3 rounded-xl bg-muted p-3">
                    <LineBadge id={line.id} />
                    <span className="flex-1 text-lg">{line.name}</span>
                    <span className="text-sm font-extrabold">
                      {etas.length ? `${etas[0] === 0 ? "acum" : etas[0] + " min"}` : "Fără GPS"}
                    </span>
                  </li>
                ))}
              </ul>
              {!arrivals.length && (
                <p>
                  Stație cartografiată în OpenStreetMap. Liniile care opresc aici nu sunt încă
                  confirmate.
                </p>
              )}
              <p className="mt-2 text-sm text-muted-foreground">
                {stopById(stop).coordinateStatus === "osm"
                  ? "Poziție din OpenStreetMap."
                  : "Poziție aproximativă; necesită verificare la locul opririi."}{" "}
                {stopById(stop).sourceUrl && (
                  <a
                    href={stopById(stop).sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Vezi sursa poziției
                  </a>
                )}
              </p>
            </>
          )}
        </section>
      )}
    </div>
  );
}

function LineBadge({ id }: { id: string }) {
  return (
    <span
      className="line-badge grid h-9 w-9 shrink-0 place-items-center rounded-lg text-sm font-bold text-white"
      style={{ background: lineById(id).color }}
    >
      {id}
    </span>
  );
}

function Lines({ onView }: { onView: (id: string) => void }) {
  return (
    <div className="lines-view h-full overflow-y-auto p-4">
      {LINES.map((l) => (
        <article key={l.id} className="route-article border-b bg-card py-5">
          <div className="mb-2 flex items-center gap-3">
            <LineBadge id={l.id} />
            <h2 className="text-xl font-extrabold">{l.name}</h2>
          </div>
          {l.routeNote && <p className="mb-3 text-sm text-muted-foreground">{l.routeNote}</p>}
          <div className="mb-3 flex flex-wrap gap-2 text-lg font-bold">
            <span className="rounded-lg bg-muted px-3 py-1">{l.km.toFixed(1)} km</span>
            <span className="rounded-lg bg-muted px-3 py-1">
              {l.first} – {l.last}
            </span>
            <span className="rounded-lg bg-muted px-3 py-1">interval {l.interval}</span>
          </div>
          <ol className="mb-4 space-y-1 border-l-4 pl-4 text-lg" style={{ borderColor: l.color }}>
            {l.stops.map((s, i) => (
              <li key={s}>
                <b>{i + 1}.</b> {stopById(s).name}
              </li>
            ))}
          </ol>
          {l.unlocatedStops?.map((s) => (
            <p key={s} className="mb-3 text-sm text-muted-foreground">
              {stopById(s).name} · poziție de confirmat
            </p>
          ))}
          <button
            onClick={() => onView(l.id)}
            className="mb-4 min-h-11 w-full rounded-xl bg-primary px-4 font-bold text-primary-foreground"
          >
            Vezi ruta {l.id} pe hartă →
          </button>
          <LineSchedule lineId={l.id} />
        </article>
      ))}
      <p className="text-sm text-muted-foreground">
        Orare și opriri din Programul de transport local Cahul, Anexa nr. 2, PDF-ul 40a publicat în
        secțiunea proiecte de decizii a Primăriei. Confirmă programul actual cu operatorul.
        Pozițiile fără o sursă cartografică exactă sunt aproximative.
      </p>
    </div>
  );
}

function Driver({
  user,
  loading,
  onLogin,
}: {
  user: User | null;
  loading: boolean;
  onLogin: () => void;
}) {
  const [name, setName] = useState("");
  const [line, setLine] = useState<string>("1");
  const [sim, setSim] = useState(false);
  const [running, setRunning] = useState(false);
  const [starting, setStarting] = useState(false);
  const [status, setStatus] = useState("");
  const idRef = useRef<string>("");
  const stopFn = useRef<() => void>(() => {});
  const startingRef = useRef(false);
  const generationRef = useRef(0);
  const pendingStop = useRef<Promise<unknown>>(Promise.resolve());

  useEffect(() => {
    setName(localStorage.getItem("cr-driver") ?? "");
  }, []);
  useEffect(() => () => stopFn.current(), []);
  useEffect(() => {
    generationRef.current++;
    stopFn.current();
    stopFn.current = () => {};
    setRunning(false);
  }, [user?.id]);

  async function start() {
    if (startingRef.current) return;
    startingRef.current = true;
    setStarting(true);
    const generation = generationRef.current;
    let wake: { release: () => Promise<void> } | null = null;
    try {
      await pendingStop.current;
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (generation !== generationRef.current) return;
      if (!session) {
        setStatus("Conectează-te pentru a porni cursa.");
        onLogin();
        return;
      }
      if (!name.trim()) {
        setStatus("Introdu numele mai întâi.");
        return;
      }
      if (!sim && !navigator.geolocation) {
        setStatus("Telefonul nu oferă GPS.");
        return;
      }
      localStorage.setItem("cr-driver", name.trim());
      idRef.current = session.user.id;
      try {
        const wl = (
          navigator as unknown as {
            wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> };
          }
        ).wakeLock;
        if (wl) wake = await wl.request("screen");
      } catch {
        /* ignore */
      }
      if (generation !== generationRef.current) {
        await wake?.release();
        return;
      }
      const vehicleId = session.user.id;
      let active = true;
      const writes = new Set<Promise<unknown>>();
      function send(lat: number, lng: number) {
        if (!active) return;
        const request = Promise.resolve(
          supabase.from("vehicles").upsert({
            id: vehicleId,
            driver_name: name.trim(),
            line,
            lat,
            lng,
            simulated: sim,
            updated_at: new Date().toISOString(),
          }),
        )
          .then(({ error }) => {
            if (active)
              setStatus(
                error
                  ? "Locația nu s-a putut trimite. Verifică internetul și accesul contului."
                  : `Locație trimisă la ${new Date().toLocaleTimeString("ro-RO")}`,
              );
          })
          .catch(() => {
            if (active) setStatus("Locația nu s-a putut trimite. Verifică internetul.");
          });
        writes.add(request);
        request.finally(() => writes.delete(request));
      }
      const l = lineById(line);
      let cleanup: () => void;
      if (sim) {
        let d = 0;
        const step = ((SPEED_KMH_SIM * 1000) / 3600) * 3;
        const tick = () => {
          const [lat, lng] = pointAt(l, d);
          send(lat, lng);
          d = (d + step) % loopPath(l).total;
        };
        tick();
        const t = setInterval(tick, 3000);
        cleanup = () => clearInterval(t);
      } else {
        let last = 0;
        const w = navigator.geolocation.watchPosition(
          (p) => {
            if (Date.now() - last > 4000) {
              last = Date.now();
              send(p.coords.latitude, p.coords.longitude);
            }
          },
          (e) => {
            if (active) setStatus("GPS indisponibil: " + e.message);
          },
          { enableHighAccuracy: true, maximumAge: 2000 },
        );
        cleanup = () => navigator.geolocation.clearWatch(w);
      }
      stopFn.current = () => {
        if (!active) return;
        active = false;
        cleanup();
        wake?.release().catch(() => {});
        pendingStop.current = Promise.allSettled([...writes])
          .then(() => supabase.from("vehicles").delete().eq("id", vehicleId))
          .catch(() => {});
      };
      setRunning(true);
      setStatus("Cursa a pornit. Ține ecranul aprins.");
    } catch {
      wake?.release().catch(() => {});
      setStatus("Cursa nu a putut porni. Verifică autentificarea și permisiunea GPS.");
    } finally {
      startingRef.current = false;
      setStarting(false);
    }
  }

  function stop() {
    stopFn.current();
    stopFn.current = () => {};
    setRunning(false);
    setStatus("Cursa s-a oprit.");
  }

  if (loading)
    return (
      <p className="p-5" role="status">
        Se verifică autentificarea…
      </p>
    );
  if (!user)
    return (
      <div className="mx-auto max-w-lg space-y-4 p-5">
        <h2 className="text-2xl font-bold">Mod Șofer</h2>
        <p>
          Conectează-te cu Google sau cu un cod primit pe email pentru a transmite poziția rutierei.
        </p>
        <button
          onClick={onLogin}
          className="min-h-14 w-full rounded-xl bg-primary px-4 text-lg font-bold text-primary-foreground"
        >
          Conectează-te
        </button>
      </div>
    );

  return (
    <div className="mx-auto flex h-full max-w-lg flex-col gap-5 overflow-y-auto p-5">
      <label className="block">
        <span className="mb-2 block text-xl font-bold">Numele șoferului</span>
        <input
          value={name}
          disabled={running || starting}
          onChange={(e) => setName(e.target.value)}
          placeholder="ex. Ion Popescu"
          maxLength={60}
          className="w-full rounded-xl border-2 border-input bg-card px-4 py-4 text-xl"
        />
      </label>
      <div>
        <span className="mb-2 block text-xl font-bold">Linia</span>
        <div className="grid grid-cols-3 gap-3">
          {LINES.map((l) => (
            <button
              key={l.id}
              disabled={running || starting}
              onClick={() => setLine(l.id)}
              className={`rounded-xl border-4 py-4 text-3xl font-black ${line === l.id ? "border-foreground" : "border-transparent opacity-60"}`}
              style={{ background: l.color, color: "#fff" }}
            >
              {l.id}
            </button>
          ))}
        </div>
        <p className="mt-2 text-lg">{lineById(line).name}</p>
      </div>
      <label className="flex items-center gap-3 text-xl font-semibold">
        <input
          type="checkbox"
          checked={sim}
          disabled={running || starting}
          onChange={(e) => setSim(e.target.checked)}
          className="h-7 w-7 accent-primary"
        />
        Mod simulare (fără GPS real)
      </label>
      <button
        disabled={starting}
        onClick={running ? stop : start}
        className={`min-h-28 rounded-3xl text-3xl font-black shadow-lg ${running ? "bg-destructive text-destructive-foreground" : "bg-go text-go-foreground"}`}
      >
        {starting ? "Se pornește…" : running ? "■ Oprește Cursa" : "▶ Pornește Cursa"}
      </button>
      {status && (
        <p className="rounded-xl bg-muted p-3 text-lg font-semibold" role="status">
          {status}
        </p>
      )}
    </div>
  );
}

const SPEED_KMH_SIM = 23;
