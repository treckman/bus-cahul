// Opriri din Programul de transport local Cahul, Anexa nr. 2, PDF-ul 40a.
// Coordonatele stațiilor sunt aproximative (după adresă, OpenStreetMap) — de verificat pe teren.
import { operatingHours } from "./schedule";
import corrections from "./route-corrections.json";
export type Stop = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  sourceUrl?: string;
  coordinateStatus?: "osm" | "approximate";
};
export type LineId = "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8";
export type Line = {
  id: LineId;
  name: string;
  color: string;
  km: number;
  first: string;
  last: string;
  interval: string;
  stops: string[];
  inboundStops?: string[];
  unlocatedStops?: string[];
  routeNote?: string;
};

const correctionByLine = corrections as Partial<
  Record<
    LineId,
    {
      excludedUnlocatedStops?: string[];
    }
  >
>;

const routeNotes: Partial<Record<LineId, string>> = {
  "1": "Urcă pe Ștefan cel Mare până la ultima oprire de pe Strada Veche.",
  "5": "Merge de pe str. Viilor pe Ștefan cel Mare, apoi prin Gara auto și M. Viteazul 27 până la ultima oprire din Lapaevca, M. Viteazul 51.",
  "6": "Tur pe Ștefan cel Mare până la Ivan Spirin 49 (La Poncik). Retur pe Ivan Spirin și Vasile Alecsandri, pe lângă Waikiki, până la M. Viteazul / Sanatoriului.",
  "8": "Merge pe Sanatoriului 2a, apoi virează pe Sfatul Țării până la ultima oprire.",
};

const routeNames: Partial<Record<LineId, string>> = {
  "1": "str. Dunării 2 – Strada Veche 147",
  "5": "str. Viilor – Lapaevca / str. M. Viteazul 51",
  "6": "M. Viteazul / Sanatoriului – Ivan Spirin 49 (La Poncik)",
  "8": "Cartierul XV – str. Sfatul Țării",
};

export const STOPS: Stop[] = [
  {
    id: "veche147",
    name: "str. Strada Veche 147",
    lat: 45.9199044,
    lng: 28.2162874,
    sourceUrl: "https://www.openstreetmap.org/node/13012679206",
    coordinateStatus: "approximate",
  },
  {
    id: "scm122",
    name: "str. Ștefan cel Mare 122",
    lat: 45.917439,
    lng: 28.2185232,
    sourceUrl: "https://www.openstreetmap.org/way/606397759",
    coordinateStatus: "approximate",
  },
  {
    id: "scm104",
    name: "str. Ștefan cel Mare 104",
    lat: 45.9123226,
    lng: 28.2102984,
    sourceUrl: "https://www.openstreetmap.org/way/157660636",
    coordinateStatus: "approximate",
  },
  { id: "pat8", name: "PAT-8", lat: 45.9127, lng: 28.2012 },
  {
    id: "scm42",
    name: "str. Ștefan cel Mare 42a",
    lat: 45.9086894,
    lng: 28.2008132,
    sourceUrl: "https://www.openstreetmap.org/way/157660636",
    coordinateStatus: "approximate",
  },
  {
    id: "scm24",
    name: "str. Ștefan cel Mare 24a",
    lat: 45.9074544,
    lng: 28.1946201,
    sourceUrl: "https://www.openstreetmap.org/way/157660636",
    coordinateStatus: "approximate",
  },
  {
    id: "indep3",
    name: "Piața Independenței 3",
    lat: 45.9042912,
    lng: 28.1939626,
    sourceUrl: "https://www.openstreetmap.org/node/8792592050",
    coordinateStatus: "approximate",
  },
  {
    id: "indep6",
    name: "Piața Independenței 6",
    lat: 45.9055826,
    lng: 28.1945383,
    sourceUrl: "https://www.openstreetmap.org/node/13012667887",
    coordinateStatus: "approximate",
  },
  {
    id: "garaauto",
    name: "Gara auto",
    lat: 45.8952117,
    lng: 28.1992065,
    sourceUrl: "https://www.openstreetmap.org/node/4268484400",
    coordinateStatus: "osm",
  },
  { id: "dun38", name: "str. Dunării 38", lat: 45.8904, lng: 28.2004 },
  {
    id: "dun17",
    name: "str. Dunării 17",
    lat: 45.8913385,
    lng: 28.1989039,
    sourceUrl: "https://www.openstreetmap.org/node/13012646233",
    coordinateStatus: "approximate",
  },
  {
    id: "dun2",
    name: "str. Dunării 2",
    lat: 45.8845016,
    lng: 28.182311,
    sourceUrl: "https://www.openstreetmap.org/node/13012640034",
    coordinateStatus: "approximate",
  },
  {
    id: "mai9",
    name: "Stradela 9 Mai",
    lat: 45.8974319,
    lng: 28.1870842,
    sourceUrl: "https://www.openstreetmap.org/way/611516162",
    coordinateStatus: "approximate",
  },
  {
    id: "chiliei",
    name: "str. Chiliei colț str. Spirin",
    lat: 45.9199037,
    lng: 28.2008864,
    sourceUrl: "https://www.openstreetmap.org/node/490609833",
    coordinateStatus: "approximate",
  },
  { id: "spirin", name: "str. Spirin", lat: 45.9208, lng: 28.2066 },
  {
    id: "spirin49",
    name: "Ivan Spirin 49 (La Poncik)",
    lat: 45.920135,
    lng: 28.20345,
    sourceUrl: "https://www.openstreetmap.org/way/1091525509",
    coordinateStatus: "approximate",
  },
  {
    id: "mv-sanat",
    name: "M. Viteazul / Sanatoriului",
    lat: 45.895413,
    lng: 28.2042493,
    sourceUrl: "https://www.openstreetmap.org/node/319499869",
    coordinateStatus: "approximate",
  },
  {
    id: "doin36",
    name: "str. Doinelor 36",
    lat: 45.894384,
    lng: 28.1954815,
    sourceUrl: "https://www.openstreetmap.org/node/13012674451",
    coordinateStatus: "approximate",
  },
  { id: "nufalb", name: "str. Nufărul Alb", lat: 45.8981, lng: 28.1849 },
  { id: "grivitei", name: "șos. Griviței", lat: 45.8868, lng: 28.1868 },
  { id: "necev", name: "str. T. Necev colț șos. Griviței", lat: 45.8822, lng: 28.1882 },
  { id: "aqua", name: "SA „Aqua-Prut”", lat: 45.9296, lng: 28.1905 },
  {
    id: "scheia2",
    name: "șos. Șcheia 2",
    lat: 45.932892,
    lng: 28.1983629,
    sourceUrl: "https://www.openstreetmap.org/node/13012668246",
    coordinateStatus: "approximate",
  },
  { id: "garafer", name: "Gara feroviară", lat: 45.9224, lng: 28.1933 },
  {
    id: "busuioc",
    name: "magazinul Busuioc",
    lat: 45.9075627,
    lng: 28.1932372,
    sourceUrl: "https://www.openstreetmap.org/node/1325087399",
    coordinateStatus: "osm",
  },
  { id: "mv27", name: "str. M. Viteazul 27", lat: 45.8955, lng: 28.2045 },
  {
    id: "mv25",
    name: "str. M. Viteazul 25",
    lat: 45.8964208,
    lng: 28.203802,
    sourceUrl: "https://www.openstreetmap.org/node/13012657511",
    coordinateStatus: "approximate",
  },
  {
    id: "mv49",
    name: "str. M. Viteazul 49",
    lat: 45.8958453,
    lng: 28.211265,
    sourceUrl: "https://www.openstreetmap.org/node/13012649271",
    coordinateStatus: "approximate",
  },
  {
    id: "mv51",
    name: "str. M. Viteazul 51",
    lat: 45.8955152,
    lng: 28.2099716,
    sourceUrl: "https://www.openstreetmap.org/node/13012656141",
    coordinateStatus: "approximate",
  },
  { id: "mv4a", name: "str. M. Viteazul 4a", lat: 45.891, lng: 28.2122 },
  {
    id: "sanat1",
    name: "Sanatoriul Nufărul Alb (str. Sanatoriului 1)",
    lat: 45.9005315,
    lng: 28.2033021,
    sourceUrl: "https://www.openstreetmap.org/node/4602020198",
    coordinateStatus: "osm",
  },
  {
    id: "sanat2a",
    name: "str. Sanatoriului 2a",
    lat: 45.8970109,
    lng: 28.2047824,
    sourceUrl: "https://www.openstreetmap.org/node/12543260638",
    coordinateStatus: "approximate",
  },
  {
    id: "haid13",
    name: "str. Haiducilor 13",
    lat: 45.9005524,
    lng: 28.2091556,
    sourceUrl: "https://www.openstreetmap.org/node/13012682912",
    coordinateStatus: "approximate",
  },
  {
    id: "sfatul",
    name: "str. Sfatul Țării",
    lat: 45.9002509,
    lng: 28.2080944,
    sourceUrl: "https://www.openstreetmap.org/way/111858592",
    coordinateStatus: "approximate",
  },
  {
    id: "cart15",
    name: "Cartierul XV",
    lat: 45.913324,
    lng: 28.2067862,
    sourceUrl: "https://www.openstreetmap.org/node/4268484895",
    coordinateStatus: "osm",
  },
  {
    id: "viilor",
    name: "str. Viilor",
    lat: 45.921616,
    lng: 28.2183856,
    sourceUrl: "https://www.openstreetmap.org/way/40483455",
    coordinateStatus: "approximate",
  },
  {
    id: "rosu",
    name: "Roșu",
    lat: 45.9539882,
    lng: 28.1930003,
    sourceUrl: "https://www.openstreetmap.org/node/12528847144",
    coordinateStatus: "osm",
  },
  { id: "alecsandri", name: "str. Vasile Alecsandri", lat: 45.9171, lng: 28.1931 },
  { id: "republicii", name: "bd. Republicii", lat: 45.9098, lng: 28.1922 },
  {
    id: "cotihana",
    name: "Cotihana",
    lat: 45.9377253,
    lng: 28.2425391,
    sourceUrl: "https://www.openstreetmap.org/node/4618946289",
    coordinateStatus: "osm",
  },
];

const BASE_LINES: Line[] = [
  {
    id: "1",
    name: "Strada Veche 147 – str. Dunării 2",
    color: "#d97706",
    km: 12.0,
    first: "06:24",
    last: "21:10",
    interval: "10–15 min",
    stops: [
      "dun2",
      "dun17",
      "dun38",
      "garaauto",
      "indep3",
      "scm24",
      "scm42",
      "pat8",
      "scm104",
      "scm122",
      "veche147",
    ],
  },
  {
    id: "2",
    name: "str. Chiliei / Spirin – str. T. Necev / șos. Griviței",
    color: "#1d4ed8",
    km: 10.0,
    first: "06:30",
    last: "20:30",
    interval: "15–20 min",
    stops: [
      "chiliei",
      "scm104",
      "pat8",
      "scm42",
      "scm24",
      "indep3",
      "garaauto",
      "doin36",
      "nufalb",
      "necev",
    ],
  },
  {
    id: "3",
    name: "SA „Aqua-Prut” – str. Sanatoriului 1",
    color: "#15803d",
    km: 12.2,
    first: "06:50",
    last: "20:45",
    interval: "15–20 min",
    stops: ["aqua", "scheia2", "garafer", "busuioc", "indep3", "garaauto", "mv27", "sanat1"],
  },
  {
    id: "4",
    name: "Cartierul XV – str. Dunării 2",
    color: "#be123c",
    km: 11.0,
    first: "06:35",
    last: "21:24",
    interval: "15–20 min",
    stops: ["cart15", "scm24", "indep3", "garaauto", "dun17", "dun2"],
  },
  {
    id: "5",
    name: "Strada Veche 147 – str. M. Viteazul 51",
    color: "#7c3aed",
    km: 10.0,
    first: "06:30",
    last: "20:50",
    interval: "15–20 min",
    stops: [
      "viilor",
      "scm122",
      "scm104",
      "pat8",
      "scm42",
      "scm24",
      "indep3",
      "garaauto",
      "mv27",
      "mv51",
    ],
  },
  {
    id: "6",
    name: "str. M. Viteazul 4a – Strada Veche 147",
    color: "#0e7490",
    km: 13.4,
    first: "06:40",
    last: "21:00",
    interval: "15–20 min",
    stops: [
      "mv-sanat",
      "garaauto",
      "indep6",
      "scm24",
      "scm42",
      "pat8",
      "scm104",
      "scm122",
      "veche147",
      "spirin49",
    ],
    inboundStops: [
      "spirin49",
      "chiliei",
      "alecsandri",
      "busuioc",
      "indep6",
      "garaauto",
      "mv-sanat",
    ],
  },
  {
    id: "7",
    name: "Roșu – Cotihana",
    color: "#4b5563",
    km: 12.2,
    first: "06:00",
    last: "21:46",
    interval: "după grafic",
    stops: ["rosu", "scheia2", "alecsandri", "republicii", "scm24", "indep3", "cotihana"],
  },
  {
    id: "8",
    name: "Cartierul XV – str. Sanatoriului 1",
    color: "#c2410c",
    km: 8.2,
    first: "06:45",
    last: "20:30",
    interval: "15–20 min",
    stops: ["cart15", "scm24", "indep3", "garaauto", "sanat2a", "sfatul"],
  },
];

export const LINES: Line[] = BASE_LINES.filter((line) => line.id !== "3" && line.id !== "7").map(
  (line) => ({
    ...line,
    name: routeNames[line.id] ?? line.name,
    routeNote: routeNotes[line.id],
    unlocatedStops: correctionByLine[line.id]?.excludedUnlocatedStops?.filter(
      (id) => id === "pat8",
    ),
    // Keep the raw municipal stop list above; display only the corrected passenger-facing stops.
    stops: line.stops.filter(
      (id) => !correctionByLine[line.id]?.excludedUnlocatedStops?.includes(id),
    ),
    ...operatingHours(line.id),
    interval: "conform orarului",
  }),
);
export const LINE_IDS = LINES.map((l) => l.id);
