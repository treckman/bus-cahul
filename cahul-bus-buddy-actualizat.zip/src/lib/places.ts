import data from "./cahul-places.json";

export type Place = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  category: string;
  address: string;
  sourceUrl: string;
};
export const PLACES: Place[] = data.places;
export const placeById = (id: string) => PLACES.find((place) => place.id === id);
export function googlePlaceUrl(place: Pick<Place, "name" | "lat" | "lng">) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${place.name}, Cahul, Moldova`)}`;
}
export function googleCoordinateUrl(lat: number, lng: number) {
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
}
