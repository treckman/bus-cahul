// Approximate coverage of the urban routes, not an administrative boundary.
export const CAHUL_SERVICE_AREA: [number, number][] = [
  [45.935, 28.19],
  [45.928, 28.222],
  [45.918, 28.232],
  [45.894, 28.229],
  [45.879, 28.21],
  [45.879, 28.178],
  [45.907, 28.177],
  [45.928, 28.18],
];

export const MAP_WORLD: [number, number][] = [
  [-85, -180],
  [-85, 180],
  [85, 180],
  [85, -180],
];
