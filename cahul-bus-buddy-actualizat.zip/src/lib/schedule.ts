import schedule from "./transport-schedule.json";

export type Direction = "outbound" | "inbound";
export const TRANSPORT_SCHEDULE = schedule;
export const servicesForLine = (line: string) =>
  schedule.services.filter((service) => service.line === line);
export function scheduledDepartures(
  line: string,
  direction: Direction = "outbound",
  code?: string,
) {
  const key = direction === "outbound" ? "outboundDeparture" : "inboundDeparture";
  return [
    ...new Set(
      servicesForLine(line)
        .filter((service) => !code || service.code === code)
        .flatMap((service) => service.trips.map((trip) => trip[key]))
        .filter((time): time is string => !!time),
    ),
  ].sort();
}
export function operatingHours(line: string) {
  const services = servicesForLine(line);
  const departures = services
    .flatMap((service) =>
      service.trips.flatMap((trip) => [trip.outboundDeparture, trip.inboundDeparture]),
    )
    .filter((time): time is string => !!time)
    .sort();
  const arrivals = services
    .flatMap((service) =>
      service.trips.flatMap((trip) => [trip.outboundArrival, trip.inboundArrival]),
    )
    .filter((time): time is string => !!time)
    .sort();
  return { first: departures[0] ?? "—", last: arrivals[arrivals.length - 1] ?? "—" };
}
