import geometry from "./route-geometry.json";
import { LINES, STOPS, type Line, type Stop } from "./transit-data";
import { scheduledDepartures } from "./schedule";
import type { Direction } from "./schedule";
import mappedStops from "./osm-stops.json";

export { LINES, STOPS, LINE_IDS } from "./transit-data";
export type { Line, Stop, LineId } from "./transit-data";

export const CAHUL_CENTER: [number, number] = [45.906, 28.2];
export const SPEED_KMH = 23;
type P = [number, number];
const GEO = geometry as unknown as Record<string, P[]>;
const DIRECTION_GEO = geometry as unknown as Record<string, { outbound: P[]; inbound: P[] }>;
export const MAPPED_STOPS: Stop[] = mappedStops as Stop[];
export const ALL_STOPS: Stop[] = [...STOPS, ...MAPPED_STOPS];

export const stopById = (id: string): Stop => ALL_STOPS.find((s) => s.id === id)!;
export const lineById = (id: string): Line => LINES.find((l) => l.id === id) ?? LINES[0]!;
export const routeStops = (line: Line, direction: Direction = "outbound"): string[] =>
  direction === "outbound" ? line.stops : (line.inboundStops ?? [...line.stops].reverse());
/** Traseul pe străzi (sens tur). */
export const routePath = (line: Line, direction: Direction = "outbound"): P[] => {
  const path = DIRECTION_GEO[line.id]?.[direction];
  if (path) return path;
  const legacy = GEO[line.id];
  if (Array.isArray(legacy)) return direction === "outbound" ? legacy : [...legacy].reverse();
  const ids = routeStops(line, direction);
  return ids.map((id) => {
    const s = stopById(id);
    return [s.lat, s.lng] as P;
  });
};

export function haversine(a: P, b: P) {
  const R = 6371000,
    toR = Math.PI / 180;
  const dLat = (b[0] - a[0]) * toR,
    dLng = (b[1] - a[1]) * toR;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * toR) * Math.cos(b[0] * toR) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

type Loop = { pts: P[]; cum: number[]; total: number; half: number };
const cache = new Map<string, Loop>();
/** Buclă tur + retur pe același traseu. */
export function loopPath(line: Line): Loop {
  const hit = cache.get(line.id);
  if (hit) return hit;
  const out = routePath(line);
  const pts = [...out, ...routePath(line, "inbound")];
  const cum = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1]! + haversine(pts[i - 1]!, pts[i]!));
  let half = 0;
  for (let i = 1; i < out.length; i++) half += haversine(out[i - 1]!, out[i]!);
  const loop = { pts, cum, total: cum[cum.length - 1]!, half };
  cache.set(line.id, loop);
  return loop;
}

export function pointAt(line: Line, dist: number): P {
  const { pts, cum, total } = loopPath(line);
  const d = ((dist % total) + total) % total;
  for (let i = 1; i < pts.length; i++) {
    if (d <= cum[i]!) {
      const a = pts[i - 1]!,
        b = pts[i]!;
      const t = (d - cum[i - 1]!) / (cum[i]! - cum[i - 1]! || 1);
      return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
    }
  }
  return pts[0]!;
}

function project(line: Line, p: P, from: number, to: number) {
  const { pts, cum } = loopPath(line);
  let best = { err: Infinity, d: 0 };
  for (let i = 1; i < pts.length; i++) {
    if (cum[i]! < from || cum[i - 1]! > to) continue;
    const a = pts[i - 1]!,
      b = pts[i]!;
    const dx = b[0] - a[0],
      dy = b[1] - a[1];
    const t = Math.max(
      0,
      Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy || 1)),
    );
    const err = haversine(p, [a[0] + dx * t, a[1] + dy * t]);
    if (err < best.err) best = { err, d: cum[i - 1]! + (cum[i]! - cum[i - 1]!) * t };
  }
  return best.d;
}

/** ETA în minute de la vehicul la stație, pe sensul de mers (tur sau retur). */
export function etaMinutes(line: Line, vehicle: P, stopId: string) {
  if (![...line.stops, ...routeStops(line, "inbound")].includes(stopId)) return null;
  const { total, half } = loopPath(line);
  const s = stopById(stopId);
  const outD = project(line, [s.lat, s.lng], 0, half);
  const targets = [
    ...(line.stops.includes(stopId) ? [outD] : []),
    ...(routeStops(line, "inbound").includes(stopId)
      ? [project(line, [s.lat, s.lng], half, total)]
      : []),
  ];
  const vd = project(line, vehicle, 0, total);
  const min = Math.min(...targets.map((t) => (t - vd + total) % total));
  return Math.max(0, Math.round(min / ((SPEED_KMH * 1000) / 60)));
}

/** Plecări orientative de la capăt între prima și ultima cursă. */
export function departures(line: Line) {
  return scheduledDepartures(line.id);
}
