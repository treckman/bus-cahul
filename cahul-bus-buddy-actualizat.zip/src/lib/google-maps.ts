// Small structural types for the official Google Maps runtime; no private tile endpoints.
export type Coordinates = { lat: number; lng: number };
type Overlay = { setMap(map: GoogleMap | null): void };
export type GoogleMap = {
  setCenter(point: Coordinates): void;
  setZoom(zoom: number): void;
  getZoom(): number | undefined;
  fitBounds(bounds: GoogleBounds, padding?: number): void;
};
type GoogleBounds = { extend(point: Coordinates): void };
type Marker = { map: GoogleMap | null; addListener(event: string, handler: () => void): void };
type Constructor<T> = new (options: Record<string, unknown>) => T;
export type GoogleMaps = {
  Map: new (element: HTMLElement, options: Record<string, unknown>) => GoogleMap;
  LatLngBounds: new () => GoogleBounds;
  Polyline: Constructor<Overlay>;
  Polygon: Constructor<Overlay>;
  Circle: Constructor<Overlay>;
  SymbolPath: { FORWARD_CLOSED_ARROW: number };
  marker: { AdvancedMarkerElement: Constructor<Marker> };
  importLibrary(name: string): Promise<unknown>;
  event: { clearInstanceListeners(instance: unknown): void };
};
type MapsWindow = Window & {
  google?: { maps: GoogleMaps };
  initCahulGoogleMaps?: () => void;
  gm_authFailure?: () => void;
};
let loading: Promise<GoogleMaps> | undefined;

export function loadGoogleMaps(key: string): Promise<GoogleMaps> {
  if (loading) return loading;
  loading = new Promise<GoogleMaps>((resolve, reject) => {
    const host = window as MapsWindow;
    const script = document.createElement("script");
    const timer = setTimeout(() => reject(new Error("Google Maps nu s-a încărcat.")), 20000);
    host.gm_authFailure = () => {
      clearTimeout(timer);
      window.dispatchEvent(new Event("cahul-google-map-error"));
      reject(new Error("Cheia Google Maps nu este autorizată."));
    };
    host.initCahulGoogleMaps = async () => {
      try {
        const maps = host.google?.maps;
        if (!maps) throw new Error("Google Maps indisponibil.");
        await maps.importLibrary("maps");
        await maps.importLibrary("marker");
        clearTimeout(timer);
        resolve(maps);
      } catch (error) {
        clearTimeout(timer);
        reject(error);
      }
    };
    script.onerror = () => {
      clearTimeout(timer);
      reject(new Error("Google Maps nu s-a încărcat."));
    };
    const params = new URLSearchParams({
      key,
      callback: "initCahulGoogleMaps",
      loading: "async",
      v: "weekly",
      language: "ro",
      region: "MD",
    });
    script.src = `https://maps.googleapis.com/maps/api/js?${params}`;
    script.async = true;
    document.head.append(script);
  });
  return loading;
}
