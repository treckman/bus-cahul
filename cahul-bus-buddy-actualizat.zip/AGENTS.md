<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Official route/stop data lives in src/lib/transit-data.ts; street geometry is precomputed (OSRM) into src/lib/route-geometry.json and regenerated when stops change; transit.ts holds ETA/path math; live positions sync via the `vehicles` table with realtime.
