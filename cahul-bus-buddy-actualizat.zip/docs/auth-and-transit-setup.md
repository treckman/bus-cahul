# CahulRutier: activare autentificare și surse de transport

## Activare în proiectul Supabase / Lovable Cloud

Pasagerii folosesc aplicația fără cont. Autentificarea este disponibilă numai pentru șoferi, prin email cu cod și sesiune persistentă. Butonul Google OAuth a fost eliminat.
Aceste setări trebuie aplicate în proiectul găzduit; fișierele locale nu activează automat furnizorii.

1. În Authentication > URL Configuration, setează Site URL la domeniul aplicației și adaugă URL-urile de redirect ale producției, preview-ului și dezvoltării locale (`http://localhost:5173/`).
2. Nu este necesară configurarea Google OAuth pentru această interfață.
3. În Email Templates > Magic Link, include `{{ .Token }}` pentru ca mesajul să conțină codul. Se poate păstra și linkul `{{ .ConfirmationURL }}`. Configurează un serviciu SMTP pentru destinatarii din afara conturilor permise de serviciul implicit.
4. Aplică migrarea `supabase/migrations/20261003000000_vehicle_account_ownership.sql` odată cu noua aplicație. Migrarea înlocuiește politicile tabelului vehicles: citire publică, modificări numai pentru vehiculul cu ID egal cu ID-ul contului autentificat. Verifică politicile existente înainte de aplicare dacă ai integrări suplimentare. Contul confirmă identitatea; nu confirmă că persoana este un șofer autorizat de operator.
5. Testează un cod corect, cod greșit/expirat, retrimitere, sesiunea după reîncărcare și deconectarea în timpul unei curse. Verifică faptul că un cont nu poate modifica vehiculul altui cont și că un utilizator anonim nu poate scrie poziții.

Documentație: https://supabase.com/docs/guides/auth/auth-email-passwordless.

## Orare și opriri

- Sursa solicitată: https://primariacahul.md/images/docs/proiecte-de-decizii/40a.pdf.
- Importate 43 de curse numerotate și 769 de rânduri tur/retur. Nu se generează ore intermediare artificiale. Celulele goale rămân goale; neconcordanțele de durată sunt marcate. Caracterul tipografic din `20.\49` este normalizat cu notă în date.
- PDF-ul este în secțiunea proiecte de decizii și are număr/data necompletate. Nu dovedește singur programul curent. Înainte de publicarea ca program oficial actual, confirmă cu Primăria/operatorii.
- Opririle din program sunt păstrate în `transit-data.ts`. Pozițiile după adresă nu sunt puncte de îmbarcare verificate. Stațiile OSM au sursă individuală și sunt afișate separat; nu le atribuim automat unei linii.
- 59 de platforme de autobuz OSM din zona Cahul/Roșu/Cotihana au fost importate. Acestea reprezintă toate platformele din interogarea OSM, nu o garanție că toate opririle reale sunt cartografiate. Dublurile din OSM sunt păstrate ca obiecte distincte.
- Geometriile tur/retur sunt reconstruite cu OSRM pe străzi între opriri. Sunt salvate în `route-geometry.json`; metadatele includ distanțele de aliniere. Nu sunt urme GPS ale operatorilor. În special ruta 6 are o neconcordanță în PDF între capătul declarat Strada Veche și lista intermediară care continuă prin Spirin și Busuioc; parcursul exact trebuie confirmat. Unele puncte, inclusiv Aqua-Prut, rămân aproximative.

## Regenerare

Cu Python și pdfplumber instalate:

```text
python scripts/import-transport-schedule.py /path/to/40a.pdf
python scripts/fetch-cahul-map.py /path/to/cahul-osm.json
python scripts/update-cahul-stops.py /path/to/cahul-osm.json
python scripts/regenerate-route-geometry.py
```

Importul OSM folosește puncte de adresă și platforme identificate explicit. Dacă un ID OSM dispare sau sursa municipală se modifică, revizuiește potrivirile înainte de regenerare. Datele OpenStreetMap sunt © OpenStreetMap contributors, ODbL: https://www.openstreetmap.org/copyright.

## Verificarea traseelor din 3 octombrie 2026

Interogarea Overpass pentru relații `type=route`, `route=bus|minibus` în zona 45.87,28.16–45.96,28.26 a returnat doar două relații interurbane (905599 Chișinău–Giurgiulești și 905604 Chișinău–Cahul). Nu conține geometria liniilor urbane 1, 2, 4, 5, 6, 8. Aceste relații nu au fost folosite pentru înlocuirea traseelor urbane.

Primăria publică și o schemă de circulație în PUG, datată 20 martie 2024: https://primariacahul.md/informatii-publice/planul-urbanistic-general/8-reglementari-cai-de-comunicatii-si-transport-reteaua-de-drumuri-si-strazi-schema-de-circulatie-a-transportului-public. Este o imagine de plan urbanistic, fără un set de coordonate verificate ale curselor actuale. Pentru corectarea geometriei sunt necesare străzile pe sens, coordonatele stațiilor sau urme GPS confirmate de operator. Nu atribuim automat platformele OSM rutelor pe baza proximității.

Interfața păstrează marcajul „Trasee orientative”, opriri în ordinea sensului selectat, săgeți de direcție și explicația preciziei. Favoritele se salvează pe dispozitiv fără cont; localizarea pasagerului rămâne locală în interfață (nu este scrisă în tabelul vehicles).

## Google Maps și locurile locale

Este implementată o hartă nativă Google Maps, cu POI-uri Google vizibile, tipuri hartă/satelit, rute, opriri numerotate și vehicule. Se activează numai dacă există `VITE_GOOGLE_MAPS_API_KEY`; fără cheie se folosește OpenStreetMap, cu locuri locale importate. Dacă încărcarea sau autorizarea Google eșuează, aplicația afișează explicit revenirea la OpenStreetMap. Nu sunt folosite adrese private de tile-uri Google.

Pentru activare:

1. În proiectul Google Cloud al proprietarului, activează Maps JavaScript API și facturarea. Nu s-a creat un cont, activat facturarea sau acceptat un cost în această sesiune.
2. Creează o cheie pentru browser restricționată la Maps JavaScript API și la domeniile aplicației, plus `http://127.0.0.1:5173/*` și `http://localhost:5173/*` pentru dezvoltare.
3. Adaugă `VITE_GOOGLE_MAPS_API_KEY` în mediul proiectului. Pentru dezvoltare locală folosește `.env.local`. Nu posta cheia în conversație și nu o comite în repository. Cheile de browser sunt incluse în frontend; restricțiile trebuie aplicate în Google Cloud.
4. Opțional configurează `VITE_GOOGLE_MAPS_MAP_ID` pentru propriul Map ID. Se folosește DEMO_MAP_ID la testarea inițială a markerelor avansate.
5. Repornește dezvoltarea/reconstruiește aplicația și verifică autorizarea, POI-urile, selectarea opririlor, live GPS și restricțiile cheii pe domeniul public. Integrarea nativă nu a fost verificată cu un cont Google real, deoarece nu există o cheie configurată.

Documentație: https://developers.google.com/maps/documentation/javascript/load-maps-js-api și https://developers.google.com/maps/documentation/javascript/usage-and-billing.

`cahul-places.json` conține 301 locuri numite, preluate din OpenStreetMap la 3 octombrie 2026. Nu este o listă exhaustivă a afacerilor și nu este o copie a catalogului Google. La mărirea hărții apar marcaje, denumiri și surse; căutarea găsește locuri după nume/adresă. `python scripts/import-cahul-places.py` reîmprospătează datele.

Au fost corectate oprirea Sanatoriul Nufărul Alb la platforma OSM 4602020198 și Gara Auto la stația OSM 4268484400, apoi au fost regenerate geometriile. Ruta 1 a fost corectată conform indicației primite pe 3 octombrie 2026 ca să urmeze Ștefan cel Mare spre Spirin și mai departe la Stradela 9 Mai; punctul PAT-8 și oprirea Dunării 38 au fost scoase din afișarea rutei 1 deoarece deviau traseul. Ruta 5 începe acum pe str. Viilor, sare peste PAT-8 și rămâne pe Ștefan cel Mare fără abatere spre Micro 15. Legătura de sus prin Strada Veche rămâne orientativă până se confirmă punctul exact de întoarcere la Spirin. Coordonata unei platforme confirmă poziția cartografiată, nu întregul parcurs al unei linii de autobuz. Google Maps/Waze descriu drumurile; traseele de transport public trebuie confirmate separat cu operatorii.
