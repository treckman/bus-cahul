"""Import the 15-column municipal transport PDF without inventing departure times.

Usage: python scripts/import-transport-schedule.py /path/to/40a.pdf
Requires pdfplumber. Source typos and suspicious rows are retained and flagged.
"""
import json
import re
import sys
from pathlib import Path
import pdfplumber

services = {}
current = None
with pdfplumber.open(sys.argv[1]) as document:
    for page_index, page in enumerate(document.pages):
        for table in page.extract_tables():
            for row in table:
                if len(row) != 15:
                    raise ValueError(f"Unexpected table structure on page {page_index + 1}")
                match = re.search(r"nr\.\s*(\d+)(?:/(\d+))?", row[0] or "")
                if match:
                    current = match.group(1) + "/" + (match.group(2) or "1")
                    if current in services:
                        raise ValueError(f"Duplicate service {current}")
                    services[current] = {
                        "line": match.group(1), "code": current,
                        "from": row[2], "to": row[3], "stops": row[4],
                        "page": page_index + 1, "days": row[12], "trips": [],
                    }
                values = [(value or "").strip() for value in row[8:12]]
                if not current or not any(re.fullmatch(r"\d{1,2}[.,:]\d{2}", v.replace("\\", "")) for v in values):
                    continue
                times = []
                notes = []
                for value in values:
                    if not value:
                        times.append(None)
                        continue
                    normalized = value.replace("\\", "")
                    if normalized != value:
                        notes.append(f"Caracter tipografic eliminat din sursă: {value}")
                    if not re.fullmatch(r"\d{1,2}[.,:]\d{2}", normalized):
                        raise ValueError((page_index + 1, current, values))
                    hour, minute = map(int, re.split(r"[.,:]", normalized))
                    if hour > 23 or minute > 59:
                        raise ValueError((page_index + 1, current, values))
                    times.append(f"{hour:02}:{minute:02}")
                for start, end in [(times[0], times[1]), (times[2], times[3])]:
                    if start and end:
                        minutes = lambda t: int(t[:2]) * 60 + int(t[3:])
                        duration = minutes(end) - minutes(start)
                        if not 0 < duration <= 60:
                            notes.append("Durată neobișnuită în document; de confirmat cu operatorul.")
                trip = dict(zip(["outboundDeparture", "outboundArrival", "inboundDeparture", "inboundArrival"], times))
                trip.update(page=page_index + 1, notes=notes)
                services[current]["trips"].append(trip)

output = {
    "sourceUrl": "https://primariacahul.md/images/docs/proiecte-de-decizii/40a.pdf",
    "sourceTitle": "Program de transport local Cahul — Anexa nr. 2",
    "retrievedAt": "2026-10-03",
    "status": "Document publicat în secțiunea proiecte de decizii; aplicabilitatea actuală trebuie confirmată cu operatorii.",
    "services": list(services.values()),
}
target = Path(__file__).resolve().parents[1] / "src/lib/transport-schedule.json"
target.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Imported {len(services)} services, {sum(len(s['trips']) for s in services.values())} rows")
for service in services.values():
    print(service["code"], len(service["trips"]))
