"""Download public OSM streets, stops and address points for Cahul.
Keeps source data outside the repository. No personal data is requested.
"""
import json
import sys
import urllib.parse
import urllib.request
query = '''[out:json][timeout:60];(
way["highway"](45.87,28.16,45.96,28.26);
node["highway"="bus_stop"](45.87,28.16,45.96,28.26);
node["public_transport"="platform"](45.87,28.16,45.96,28.26);
nwr["addr:housenumber"](45.87,28.16,45.96,28.26);
);out center geom;'''
request = urllib.request.Request('https://overpass-api.de/api/interpreter', data=urllib.parse.urlencode({'data': query}).encode(), headers={'User-Agent': 'CahulRutier/1.0 (public transit map verification)'})
with urllib.request.urlopen(request, timeout=90) as response:
    payload = response.read()
data = json.loads(payload)
if 'remark' in data: raise RuntimeError(data['remark'])
with open(sys.argv[1], 'wb') as output: output.write(payload)
print(f"Downloaded {len(data['elements'])} OSM elements")
