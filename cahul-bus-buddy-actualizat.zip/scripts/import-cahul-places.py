"""Fetch named public places and station landmarks in Cahul from OSM.
No route membership is inferred from nearby places. OSM is not an exhaustive
business directory. Usage: python scripts/import-cahul-places.py
"""
import json
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

query = '''[out:json][timeout:45];(
nwr["name"][~"^(shop|amenity|tourism|office|craft)$"~"."](45.875,28.175,45.94,28.24);
node["highway"="bus_stop"](45.875,28.175,45.94,28.24);
);out center;'''
request = urllib.request.Request(
    'https://overpass-api.de/api/interpreter',
    data=urllib.parse.urlencode({'data': query}).encode(),
    headers={'User-Agent': 'CahulRutier/1.0 public places import'},
)
with urllib.request.urlopen(request, timeout=60) as response:
    data = json.load(response)
if 'remark' in data:
    raise RuntimeError(data['remark'])
places = []
for element in data['elements']:
    tags = element.get('tags', {})
    if tags.get('highway') == 'bus_stop' and not any(k in tags for k in ['shop', 'amenity', 'tourism', 'office', 'craft']):
        continue
    name = tags.get('name:ro') or tags.get('name')
    if not name:
        continue
    position = element.get('center', element)
    category = next((tags[k] for k in ['shop', 'amenity', 'tourism', 'office', 'craft'] if k in tags), 'place')
    places.append({
        'id': f'{element["type"]}-{element["id"]}', 'name': name,
        'lat': position['lat'], 'lng': position['lon'], 'category': category,
        'sourceUrl': f'https://www.openstreetmap.org/{element["type"]}/{element["id"]}',
        'address': ', '.join(filter(None, [tags.get('addr:street'), tags.get('addr:housenumber')])),
    })
root = Path(__file__).resolve().parents[1]
output = {'source': 'OpenStreetMap', 'retrievedAt': datetime.now(timezone.utc).isoformat(), 'coverage': 'Named places mapped in OSM; not every local business', 'places': places}
(root / 'src/lib/cahul-places.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(root / 'cahul-landmarks-source.json').write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
print(f'Imported {len(places)} named places')
