"""Update verified OSM address anchors and import mapped bus platforms.
Usage: python scripts/update-cahul-stops.py /path/to/cahul-osm.json
Address anchors locate the address, not a surveyed bus boarding point.
"""
import json
import re
import sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
elements = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))['elements']
nodes = {e['id']: e for e in elements if e['type'] == 'node'}
anchors = {
    'veche147': 13012679206, 'scm122': 13012650432, 'scm104': 13012658310,
    'indep3': 8792592050, 'indep6': 13012667887,
    'dun17': 13012646233, 'dun2': 13012640034, 'doin36': 13012674451,
    'scheia2': 13012668246, 'mv25': 13012657511, 'mv49': 13012649271,
    'mv51': 13012656141, 'sanat2a': 12543260638, 'haid13': 13012682912,
}
platforms = {'busuioc': 1325087399, 'cart15': 4268484895, 'sanat1': 4602020198, 'rosu': 12528847144, 'cotihana': 4618946289}
text = (root / 'src/lib/transit-data.ts').read_text(encoding='utf-8')
for stop_id, osm_id in {**anchors, **platforms}.items():
    node = nodes[osm_id]
    status = 'osm' if stop_id in platforms else 'approximate'
    replacement = f'lat: {node["lat"]}, lng: {node["lon"]}, sourceUrl: "https://www.openstreetmap.org/node/{osm_id}", coordinateStatus: "{status}"'
    text, count = re.subn(r'(\{\s*id:\s*"' + stop_id + r'",\s*name:\s*"[^"]*",\s*)lat:\s*[^}]+(?=\})', lambda m: m[1] + replacement, text)
    if count != 1: raise ValueError(stop_id)
# Actual street junction, determined from OSM way nodes shared by Chiliei and Spirin.
ways = [e for e in elements if e['type'] == 'way' and 'highway' in e.get('tags', {})]
chiliei = [e for e in ways if e['tags'].get('name') == 'Strada Chiliei']
spirin = [e for e in ways if e['tags'].get('name') == 'Strada Ivan Spirin']
shared = set(n for e in chiliei for n in e['nodes']) & set(n for e in spirin for n in e['nodes'])
for way in chiliei:
    for node_id, point in zip(way['nodes'], way['geometry']):
        if node_id in shared:
            replacement = f'lat: {point["lat"]}, lng: {point["lon"]}, sourceUrl: "https://www.openstreetmap.org/node/{node_id}", coordinateStatus: "approximate"'
            text = re.sub(r'(\{\s*id:\s*"chiliei",\s*name:\s*"[^"]*",\s*)lat:\s*[^}]+(?=\})', lambda m: m[1] + replacement, text)
            print('Chiliei / Spirin', point)
# Map a stop to the address vicinity, explicitly retaining approximate status.
for stop_id, osm_id in {'scm42': 13012646267, 'scm24': 13012653225}.items():
    node = nodes[osm_id]
    replacement = f'lat: {node["lat"]}, lng: {node["lon"]}, sourceUrl: "https://www.openstreetmap.org/node/{osm_id}", coordinateStatus: "approximate"'
    text = re.sub(r'(\{\s*id:\s*"' + stop_id + r'",\s*name:\s*"[^"]*",\s*)lat:\s*[^}]+(?=\})', lambda m: m[1] + replacement, text)
text = text.replace('"chiliei", "spirin", "scm104"', '"chiliei", "scm104"').replace('"nufalb", "grivitei", "necev"', '"nufalb", "necev"')
# Preserve the user-corrected street corridor rather than restoring side-street
# address points that caused OSRM to leave Stefan cel Mare.
corrections = json.loads((root / 'src/lib/route-corrections.json').read_text(encoding='utf-8'))
for stop_id, point in corrections['1']['streetStopCoordinates'].items():
    replacement = f'lat: {point["lat"]}, lng: {point["lng"]}, sourceUrl: "{point["sourceUrl"]}", coordinateStatus: "approximate"'
    text = re.sub(r'(\{\s*id:\s*"' + stop_id + r'",\s*name:\s*"[^"]*",\s*)lat:\s*[^}]+(?=\})', lambda m: m[1] + replacement, text)
(root / 'src/lib/transit-data.ts').write_text(text, encoding='utf-8')
stops = []
for node in nodes.values():
    tags = node.get('tags', {})
    if tags.get('highway') != 'bus_stop' and not (tags.get('public_transport') == 'platform' and tags.get('bus') == 'yes'):
        continue
    name = tags.get('name:ro') or tags.get('name') or 'Stație de transport public'
    stops.append({'id': f'osm-{node["id"]}', 'name': name, 'lat': node['lat'], 'lng': node['lon'], 'sourceUrl': f'https://www.openstreetmap.org/node/{node["id"]}', 'coordinateStatus': 'osm'})
(root / 'src/lib/osm-stops.json').write_text(json.dumps(stops, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f'Imported {len(stops)} mapped bus platforms; route membership is not inferred.')
