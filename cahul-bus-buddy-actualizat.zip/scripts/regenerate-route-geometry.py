"""Reconstruct road paths between municipal stop anchors with OSRM.
This does NOT verify that the operator follows the computed streets.
Usage: python scripts/regenerate-route-geometry.py
Only replaces the JSON after every direction was successfully fetched.
"""
import json
import re
import sys
import time
import urllib.request
from pathlib import Path
root = Path(__file__).resolve().parents[1]
text = (root / 'src/lib/transit-data.ts').read_text(encoding='utf-8')
stops = {m[1]: (float(m[2]), float(m[3])) for m in re.finditer(r'\{\s*id:\s*"([^"]+)",\s*name:\s*"[^"]+",\s*lat:\s*([\d.]+),\s*lng:\s*([\d.]+)', text)}
lines = {m[1]: re.findall(r'"([^"]+)"', m[2]) for m in re.finditer(r'\{\s*id:\s*"(\d+)",\s*name:[\s\S]*?stops:\s*\[([^\]]+)\]', text)}
if len(lines) != 8 or not all(s in stops for ids in lines.values() for s in ids): raise ValueError('Incomplete route/stop parsing')
corrections = json.loads((root / 'src/lib/route-corrections.json').read_text(encoding='utf-8'))
geometry = json.loads((root / 'src/lib/route-geometry.json').read_text(encoding='utf-8'))
metadata = json.loads((root / 'src/lib/route-geometry-meta.json').read_text(encoding='utf-8'))
selected = set(sys.argv[1:]) or set(lines)
for line, stop_ids in lines.items():
    if line not in selected:
        continue
    geometry[line] = {}
    metadata['routes'][line] = {}
    for direction in ['outbound', 'inbound']:
        ids = stop_ids if direction == 'outbound' else list(reversed(stop_ids))
        override = corrections.get(line)
        if override:
            anchors = override['outboundAnchors'] if direction == 'outbound' else override.get('inboundAnchors', list(reversed(override['outboundAnchors'])))
            points = [stops[a['stop']] if 'stop' in a else (a['lat'], a['lng']) for a in anchors]
            ids = [a.get('stop', f'control-{i}') for i, a in enumerate(anchors)]
        else:
            points = [stops[s] for s in ids]
        coords = ';'.join(f'{lng},{lat}' for lat, lng in points)
        url = 'https://router.project-osrm.org/route/v1/driving/' + coords + '?overview=full&geometries=geojson&steps=false&continue_straight=false'
        request = urllib.request.Request(url, headers={'User-Agent': 'CahulRutier/1.0'})
        with urllib.request.urlopen(request, timeout=45) as response: result = json.load(response)
        if result.get('code') != 'Ok': raise RuntimeError((line, direction, result.get('code')))
        route = result['routes'][0]
        geometry[line][direction] = [[round(lat, 7), round(lon, 7)] for lon, lat in route['geometry']['coordinates']]
        metadata['routes'][line][direction] = {'distanceMeters': round(route['distance']), 'snapDistances': {s: round(w['distance'], 1) for s, w in zip(ids, result['waypoints'])}}
        if override:
            metadata['routes'][line][direction]['correctionSource'] = override['source']
            metadata['routes'][line][direction]['assumption'] = override['assumption']
        print(line, direction, len(geometry[line][direction]), 'points, max snap', max(w['distance'] for w in result['waypoints']), flush=True)
        time.sleep(1)
for name, data in [('route-geometry.json', geometry), ('route-geometry-meta.json', metadata)]:
    (root / 'src/lib' / name).write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
